using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Coflow.Loader
{
public sealed class LoadResult<T> where T : class
{
    private readonly T? _data;
    internal LoadResult(T? data, IReadOnlyList<CfdDiagnostic> diagnostics) { _data = data; Diagnostics = diagnostics; }
    public bool Success => _data != null;
    public T Data => _data ?? throw new InvalidOperationException("Loading failed; inspect Diagnostics.");
    public IReadOnlyList<CfdDiagnostic> Diagnostics { get; }
}

public static class CfdLoader
{
    public static LoadResult<T> Load<T>(IEnumerable<CfdSource> sources, IReadOnlyList<CfdType> types, Func<CfdData, T> construct, IReadOnlyDictionary<string, CfdValueNode>? constants = null) where T : class
    {
        if (sources == null || types == null || construct == null) throw new ArgumentNullException();
        try
        {
            var context = new LoadContext(CfdParser.ParseAll(sources), types, constants);
            context.Build();
            // 成功后交付共享数据与轻量访问视图，所有基础及单维变体已校验。
            return new LoadResult<T>(construct(new CfdData(types, context)), System.Array.Empty<CfdDiagnostic>());
        }
        catch (CfdLoadException error) { return new LoadResult<T>(null, error.Diagnostics); }
    }
}

public sealed class CfdData
{
    private readonly Dictionary<Type, object> _tables = new Dictionary<Type, object>();
    private readonly Dictionary<Type, object> _singletons = new Dictionary<Type, object>();
    internal CfdData(IReadOnlyList<CfdType> types, LoadContext context)
    {
        // 注册类别决定可访问入口，data 不进入记录表；重复获取返回同一只读表。
        foreach (var type in types)
        {
            if (type.Kind == CfdTypeKind.Table) _tables.Add(type.ValueType, type.BuildTable(context.RecordsFor(type)));
            if (type.Kind == CfdTypeKind.Singleton) _singletons.Add(type.ValueType, type.BuildSingleton(context.RecordsFor(type)));
        }
    }
    public Table<T> Table<T>() where T : class => _tables.TryGetValue(typeof(T), out var table)
        ? (Table<T>)table : throw new InvalidOperationException($"`{typeof(T).Name}` is not a table in this schema.");
    public T Singleton<T>() where T : class => _singletons.TryGetValue(typeof(T), out var value)
        ? (T)value : throw new InvalidOperationException($"`{typeof(T).Name}` is not a singleton in this schema.");
}

internal sealed class RecordState
{
    internal RecordState(CfdType type, string id, string path, CfdSpan span)
    { Data = new ObjectData(type, path, span, id); Data.Record = this; }
    internal ObjectData Data { get; }
    internal string Id => Data.Id!;
    internal CfdType Type => Data.Type;
    internal string Path => Data.Path;
    internal object Value { get; set; } = null!;
}

internal sealed class ObjectData
{
    internal ObjectData(CfdType type, string path, CfdSpan span, string? id = null)
    { Type = type; Path = path; Span = span; Id = id; Fields = new BoundField[type.Fields.Length]; }
    internal CfdType Type { get; }
    internal string Path { get; }
    internal CfdSpan Span { get; }
    internal string? Id { get; }
    internal RecordState? Record { get; set; }
    internal BoundField[] Fields { get; }
    internal Dictionary<int, Dictionary<string, BoundField>>? Overrides { get; set; }
    internal bool NeedsEvaluation { get; set; }
    internal bool IsFixed => Overrides == null && !NeedsEvaluation;
}
internal readonly struct SourceField
{
    internal SourceField(CfdValueNode node, string path) { Node = node; Path = path; }
    internal CfdValueNode Node { get; }
    internal string Path { get; }
}
internal readonly struct BoundField
{
    internal BoundField(BoundValue value, string path, CfdSpan span) { Value = value; Path = path; Span = span; }
    internal BoundValue Value { get; }
    internal string Path { get; }
    internal CfdSpan Span { get; }
}

internal sealed class LoadContext
{
    private readonly Dictionary<string, CfdType> _types;
    private readonly Dictionary<(DimensionSelection, string, string), ViewSession> _transitions = new Dictionary<(DimensionSelection, string, string), ViewSession>();
    private readonly Dictionary<string, ViewSession> _views = new Dictionary<string, ViewSession>(StringComparer.Ordinal);
    private readonly Dictionary<string, IReadOnlyList<string>> _variantNames = new Dictionary<string, IReadOnlyList<string>>(StringComparer.Ordinal);
    private readonly Dictionary<(string Root, string Id), RecordState> _recordsByIdentity = new Dictionary<(string Root, string Id), RecordState>();
    private readonly Dictionary<string, List<RecordState>> _recordsById = new Dictionary<string, List<RecordState>>(StringComparer.Ordinal);
    private IReadOnlyDictionary<string, CfdValueNode> _constants;
    internal ViewSession Base { get; private set; } = null!;
    internal CfdValueNode ResolveConstant(CfdValueNode node) => node is CfdScalarValue scalar && _constants.TryGetValue(scalar.Value, out var value) ? value : node;
    internal IReadOnlyList<string> DimensionVariants(string dimension)
        => _variantNames.TryGetValue(dimension, out var variants) ? variants : throw new ArgumentException($"Unknown dimension `{dimension}`.", nameof(dimension));
    internal object For(RecordState record, DimensionSelection current, string dimension, string variant)
    {
        lock (_views)
        {
            var variants = DimensionVariants(dimension);
            if (variant == null) throw new ArgumentNullException(nameof(variant));
            if (!Variants[dimension].Contains(variant))
                throw new ArgumentException($"Unknown variant `{variant}` for dimension `{dimension}`. Loaded variants: [{string.Join(", ", variants)}].", nameof(variant));
            // 重复选择复用同一会话，避免热点 For 分配选择数组和键字符串。
            var transition = (current, dimension, variant);
            if (_transitions.TryGetValue(transition, out var cached)) return cached.Reader(record.Data).View;
            var selection = current.With(dimension, variant);
            if (!_views.TryGetValue(selection.Key, out var session)) _views.Add(selection.Key, session = new ViewSession(this, selection));
            _transitions.Add(transition, session);
            return session.Reader(record.Data).View;
        }
    }
    private sealed class TypePlan
    {
        internal TypePlan(CfdType[] lineage) { Lineage = lineage; Root = lineage[lineage.Length - 1].Name; Ancestors = new HashSet<CfdType>(lineage); }
        internal CfdType[] Lineage { get; }
        internal string Root { get; }
        internal HashSet<CfdType> Ancestors { get; }
    }
    private readonly Dictionary<CfdType, TypePlan> _typePlans = new Dictionary<CfdType, TypePlan>();
    private readonly Dictionary<CfdType, List<RecordState>> _recordsByType = new Dictionary<CfdType, List<RecordState>>();
    internal IReadOnlyList<RecordState> RecordsFor(CfdType type) => _recordsByType[type];
    internal List<RecordState> Records { get; } = new List<RecordState>();
    internal Dictionary<string, SortedSet<string>> Variants { get; } = new Dictionary<string, SortedSet<string>>(StringComparer.Ordinal);
    internal LoadContext(IReadOnlyList<CfdDocument> documents, IReadOnlyList<CfdType> types, IReadOnlyDictionary<string, CfdValueNode>? constants)
    {
        _constants = constants ?? new Dictionary<string, CfdValueNode>(StringComparer.Ordinal);
        _types = types.ToDictionary(type => type.Name, StringComparer.Ordinal);
        Base = new ViewSession(this, DimensionSelection.Empty);
        // 继承关系与表成员在本次加载中只编译一次，父表直接共享派生记录身份。
        foreach (var type in types)
        {
            var lineage = new List<CfdType>();
            for (var ancestor = type; ancestor != null; ancestor = ancestor.Parent == null ? null : _types[ancestor.Parent]) lineage.Add(ancestor);
            _typePlans.Add(type, new TypePlan(lineage.ToArray()));
            if (type.Kind != CfdTypeKind.Data) _recordsByType.Add(type, new List<RecordState>());
        }
        foreach (var type in types)
            foreach (var field in type.Fields)
                if (field.Dimension is string dimension && !Variants.ContainsKey(dimension)) Variants.Add(dimension, new SortedSet<string>(StringComparer.Ordinal));
        // 全部记录先建立身份，基础文件与覆盖文件顺序不影响解析结果。
        foreach (var document in documents)
            foreach (var node in document.Records)
            {
                if (!_types.TryGetValue(node.DeclaredType, out var type) || type.Kind == CfdTypeKind.Data || type.IsAbstract)
                    throw Error("CFD-TYPE", $"invalid record type `{node.DeclaredType}`", document.Path, node.Span);
                // 分组声明限定实际类型，未知分组与无关类型不能绕过继承校验。
                if (node.GroupType != null && (!_types.TryGetValue(node.GroupType, out var group) || group.Kind != CfdTypeKind.Table || !Assignable(type, node.GroupType)))
                    throw Error("CFD-TYPE", $"record type `{type.Name}` is not assignable to group `{node.GroupType}`", document.Path, node.Span);
                var identity = (Root(type), node.Id);
                if (_recordsByIdentity.ContainsKey(identity))
                    throw Error("CFD-DUPLICATE", $"duplicate record `{node.Id}`", document.Path, node.Span);
                var record = new RecordState(type, node.Id, document.Path, node.Span);
                Records.Add(record);
                foreach (var ancestor in _typePlans[type].Lineage)
                    if (ancestor.Kind != CfdTypeKind.Data) _recordsByType[ancestor].Add(record);
                // 引用按继承树与 id 建立临时索引，加载过程不逐条扫描全部记录。
                _recordsByIdentity.Add(identity, record);
                if (!_recordsById.TryGetValue(node.Id, out var matching))
                    _recordsById.Add(node.Id, matching = new List<RecordState>());
                matching.Add(record);
            }
        foreach (var type in types.Where(type => type.Kind == CfdTypeKind.Singleton))
        {
            var records = _recordsByType[type];
            if (records.Count != 1)
                throw Error("CFD-SINGLETON", $"singleton `{type.Name}` requires exactly one record", "", default);
            // 单例身份来自声明短名，和 Rust 数据模型使用同一条 id 规则。
            var id = type.Name.Substring(type.Name.LastIndexOf('.') + 1);
            if (records[0].Id != id)
                throw Error("CFD-SINGLETON", $"singleton `{type.Name}` requires record id `{id}`", records[0].Path, records[0].Data.Span);
        }
        var overrides = new Dictionary<RecordState, Dictionary<int, Dictionary<string, SourceField>>>();
        foreach (var document in documents)
            foreach (var block in document.Dimensions)
            {
                if (!Variants.TryGetValue(block.Dimension, out var variants))
                    throw Error("CFD-DIMENSION", $"unknown dimension `{block.Dimension}`", document.Path, block.Span);
                variants.Add(block.Variant);
                foreach (var target in block.Records)
                {
                    var record = Find(target.DeclaredType, target.Id, document.Path, target.Span);
                    if (!overrides.TryGetValue(record, out var fields)) overrides.Add(record, fields = new Dictionary<int, Dictionary<string, SourceField>>());
                    foreach (var field in target.Fields)
                    {
                        var ordinal = record.Type.FindOrdinal(field.Name);
                        if (ordinal < 0 || record.Type.Fields[ordinal].Dimension != block.Dimension)
                            throw Error("CFD-DIMENSION", $"field `{field.Name}` is not bound to dimension `{block.Dimension}`", document.Path, field.Span);
                        if (!fields.TryGetValue(ordinal, out var values)) fields.Add(ordinal, values = new Dictionary<string, SourceField>(StringComparer.Ordinal));
                        if (values.ContainsKey(block.Variant)) throw Error("CFD-DUPLICATE-OVERLAY", $"duplicate override `{block.Dimension}[{block.Variant}]::{target.Id}.{field.Name}`", document.Path, field.Span);
                        values.Add(block.Variant, new SourceField(field.Value, document.Path));
                    }
                }
            }
        // 身份索引先完整建立，再绑定字段；普通引用不会递归构造业务对象。
        foreach (var document in documents)
            foreach (var node in document.Records)
            {
                var record = Find(node.DeclaredType, node.Id, document.Path, node.Span);
                overrides.TryGetValue(record, out var fields);
                BindFields(record.Data, node.Fields, fields);
            }
        // 绑定已把名称解析为直接身份和字段序号，运行期不保留解析索引或常量语法节点。
        _constants = new Dictionary<string, CfdValueNode>();
        _recordsByIdentity.Clear();
        _recordsById.Clear();
        _typePlans.Clear();
        _types.Clear();
        // 已发现变体在加载结束后固定，所有记录复用一次排序后的只读列表。
        foreach (var dimension in Variants)
            _variantNames.Add(dimension.Key, System.Array.AsReadOnly(dimension.Value.ToArray()));
    }
    private string Root(CfdType type) => _typePlans[type].Root;
    internal bool Assignable(CfdType actual, string expected) => _types.TryGetValue(expected, out var type) && _typePlans[actual].Ancestors.Contains(type);
    internal RecordState Find(string? type, string id, string path, CfdSpan span)
    {
        if (type != null)
        {
            if (_types.TryGetValue(type, out var expected)
                && _recordsByIdentity.TryGetValue((Root(expected), id), out var record)
                && Assignable(record.Type, type)) return record;
        }
        else if (_recordsById.TryGetValue(id, out var matching) && matching.Count == 1)
            return matching[0];
        throw Error("CFD-REFERENCE", $"record `{type}::{id}` is missing or ambiguous", path, span);
    }
    private int _bindingDepth;
    private void BindFields(ObjectData data, IReadOnlyList<CfdFieldNode> fields, Dictionary<int, Dictionary<string, SourceField>>? overrides = null)
    {
        if (++_bindingDepth > 256) { _bindingDepth--; throw Error("CFD-LIMIT", "construction nesting exceeds 256 levels", data.Path, data.Span); }
        try
        {
            var nodes = new CfdValueNode?[data.Fields.Length];
            foreach (var field in fields)
            {
                var ordinal = data.Type.FindOrdinal(field.Name);
                if (ordinal < 0) throw Error("CFD-FIELD", $"unknown field `{field.Name}`", data.Path, field.Span);
                if (nodes[ordinal] != null) throw Error("CFD-DUPLICATE-FIELD", $"duplicate field `{field.Name}`", data.Path, field.Span);
                nodes[ordinal] = field.Value;
            }
            for (var i = 0; i < nodes.Length; i++)
            {
                var descriptor = data.Type.Fields[i];
                var node = nodes[i] ?? descriptor.DefaultValue ?? throw Error("CFD-MISSING", $"missing required field `{descriptor.Name}`", data.Path, data.Span);
                data.Fields[i] = new BoundField(descriptor.Type.Bind(this, node, new BindingScope(data.Type, data.Path)), data.Path, node.Span);
            }
            data.NeedsEvaluation = data.Fields.Any(field => !field.Value.IsFixed);
            if (overrides == null) return;
            data.Overrides = new Dictionary<int, Dictionary<string, BoundField>>();
            foreach (var field in overrides)
            {
                var values = new Dictionary<string, BoundField>(StringComparer.Ordinal);
                foreach (var variant in field.Value)
                {
                    var source = variant.Value;
                    values.Add(variant.Key, new BoundField(data.Type.Fields[field.Key].Type.Bind(this, source.Node, new BindingScope(data.Type, source.Path)), source.Path, source.Node.Span));
                }
                data.Overrides.Add(field.Key, values);
                data.NeedsEvaluation |= values.Values.Any(value => !value.Value.IsFixed);
            }
        }
        finally { _bindingDepth--; }
    }
    internal void Build()
    {
        // 验证会话不进入业务视图缓存；只保留实际访问的表达式结果。
        Validate(DimensionSelection.Empty);
        foreach (var dimension in Variants)
            foreach (var variant in dimension.Value) Validate(DimensionSelection.Empty.With(dimension.Key, variant));
        foreach (var record in Records) record.Value = Base.Reader(record.Data).View;
    }
    private void Validate(DimensionSelection selection)
    {
        var session = new ViewSession(this, selection);
        foreach (var record in Records) session.Validate(record.Data);
    }
    internal BoundValue<T> BindReference<T>(string expected, CfdValueNode node, BindingScope owner) where T : class
    {
        if (!(node is CfdReferenceValue reference)) throw owner.Error(node, "CFD-TYPE", "expected record reference");
        var record = Find(reference.TypeName ?? expected, reference.Id, owner.Path, node.Span);
        if (!Assignable(record.Type, expected) || !typeof(T).IsAssignableFrom(record.Type.ValueType)) throw owner.Error(node, "CFD-TYPE", "reference type mismatch");
        return new BoundValue<T>(reader => (T)reader.Session.Reader(record.Data).View,
            reader => reader.Session.Validate(record.Data), reader => reader.Session.Reader(record.Data));
    }
    internal BoundValue<T> BindObject<T>(string expected, CfdValueNode node, BindingScope owner)
    {
        string? actual;
        IReadOnlyList<CfdFieldNode> fields;
        if (node is CfdObjectValue obj) { actual = obj.DeclaredType; fields = obj.Fields; }
        else if (node is CfdDictionaryValue dictionary)
        {
            actual = null;
            fields = dictionary.Entries.Select(entry => new CfdFieldNode(entry.Key is CfdScalarValue key ? key.Value : entry.Key is CfdStringValue text ? text.Value : throw owner.Error(entry.Key, "CFD-TYPE", "expected field name"), entry.Value, entry.Span)).ToArray();
        }
        else throw owner.Error(node, "CFD-TYPE", "expected inline data object");
        if (!_types.TryGetValue(actual ?? expected, out var type) || type.Kind != CfdTypeKind.Data || type.IsAbstract || !Assignable(type, expected)
            || !typeof(T).IsAssignableFrom(type.ValueType)) throw owner.Error(node, "CFD-TYPE", "inline object type mismatch");
        var data = new ObjectData(type, owner.Path, node.Span);
        BindFields(data, fields);
        if (data.IsFixed)
        {
            var fixedReader = Base.Reader(data);
            return new BoundValue<T>((T)fixedReader.View, _ => fixedReader);
        }
        return new BoundValue<T>(reader => (T)reader.Session.Reader(data).View,
            reader => reader.Session.Validate(data), reader => reader.Session.Reader(data));
    }
    internal BoundValue<string> BindTemplate(CfdFormattedStringValue template, BindingScope owner)
    {
        var parts = new List<Func<CfdReader, string>>();
        foreach (var segment in template.Segments)
        {
            if (segment is CfdFormatText text) { parts.Add(_ => text.Text); continue; }
            var reference = (CfdFormatReference)segment;
            var record = reference.Id == null ? null : Find(reference.TypeName, reference.Id, owner.Path, template.Span);
            var type = record?.Type ?? owner.Type;
            var start = reference.Id == null ? 1 : 0;
            var ordinals = new List<int>();
            var id = false;
            CfdValueType? terminal = null;
            for (var i = start; i < reference.Path.Count; i++)
            {
                var name = reference.Path[i];
                if (i == reference.Path.Count - 1 && name == "id" && type.Kind != CfdTypeKind.Data) { id = true; break; }
                var ordinal = type.FindOrdinal(name);
                if (ordinal < 0) throw owner.Error(template, "CFD-FIELD", $"unknown field `{name}`");
                var field = type.Fields[ordinal];
                ordinals.Add(ordinal);
                terminal = field.Type;
                if (i == reference.Path.Count - 1) break;
                if (field.Type.IsOptional) throw owner.Error(template, "CFD-INTERPOLATION", "field path cannot traverse an optional value");
                if (field.Type.NamedType == null || !_types.TryGetValue(field.Type.NamedType, out type!))
                    throw owner.Error(template, "CFD-INTERPOLATION", "field path must traverse data or a record reference");
            }
            if (ordinals.Count == 0 && !id) throw owner.Error(template, "CFD-INTERPOLATION", "empty field path");
            var path = ordinals.ToArray();
            var terminalType = terminal;
            var pathText = owner.Path;
            var span = template.Span;
            parts.Add(reader =>
            {
                var current = record == null ? reader : reader.Session.Reader(record.Data);
                var count = id ? path.Length : path.Length - 1;
                for (var i = 0; i < count; i++)
                    current = current.Source(path[i]).Value.Traverse(current)
                        ?? throw Error("CFD-INTERPOLATION", "field path must traverse data or a record reference", pathText, span);
                if (id) return current.Id;
                return terminalType!.FormatScalar(current.Read(path[path.Length - 1]))
                    ?? throw Error("CFD-INTERPOLATION", "interpolation requires a string, number, bool or enum field", pathText, span);
            });
        }
        return new BoundValue<string>(reader =>
        {
            var output = new StringBuilder();
            foreach (var part in parts) output.Append(part(reader));
            return output.ToString();
        });
    }
    internal static CfdLoadException Error(string code, string message, string path, CfdSpan span) => new CfdLoadException(new[] { new CfdDiagnostic(code, message, path, span) });
}

// 每个上下文只缓存已访问的轻量对象和表达式；普通字段没有逐视图结果数组。
internal sealed class ViewSession
{
    internal readonly object Sync = new object();
    internal readonly LoadContext Context;
    internal readonly DimensionSelection Selection;
    private readonly Dictionary<ObjectData, CfdReader> _readers = new Dictionary<ObjectData, CfdReader>();
    private readonly HashSet<ObjectData> _validated = new HashSet<ObjectData>();
    private readonly HashSet<(ObjectData, int)> _evaluating = new HashSet<(ObjectData, int)>();
    internal ViewSession(LoadContext context, DimensionSelection selection) { Context = context; Selection = selection; }
    internal CfdReader Reader(ObjectData data)
    {
        lock (Sync)
        {
            if (!_readers.TryGetValue(data, out var reader)) _readers.Add(data, reader = new CfdReader(this, data));
            return reader;
        }
    }
    internal void Validate(ObjectData data)
    {
        // 纯值及其覆盖已在绑定时完成校验，不为每个变体重复建立读取器。
        if (!data.NeedsEvaluation || !_validated.Add(data)) return;
        var reader = Reader(data);
        for (var i = 0; i < data.Fields.Length; i++)
        {
            var value = reader.Source(i).Value;
            if (value.IsFixed) continue;
            var key = (data, i);
            if (!_evaluating.Add(key)) throw LoadContext.Error("CFD-INTERPOLATION-CYCLE", "cyclic field dependency", data.Path, data.Span);
            try
            {
                if (_evaluating.Count > 256) throw LoadContext.Error("CFD-LIMIT", "construction nesting exceeds 256 levels", data.Path, data.Span);
                value.Validate(reader);
            }
            finally { _evaluating.Remove(key); }
        }
    }
    internal object? Evaluate(CfdReader reader, int ordinal, BoundField field)
    {
        var key = (reader.Data, ordinal);
        if (!_evaluating.Add(key)) throw LoadContext.Error("CFD-INTERPOLATION-CYCLE", $"cyclic field dependency `{reader.Data.Type.Fields[ordinal].Name}`", field.Path, field.Span);
        try
        {
            if (_evaluating.Count > 256) throw LoadContext.Error("CFD-LIMIT", "construction nesting exceeds 256 levels", field.Path, field.Span);
            return field.Value.Read(reader);
        }
        finally { _evaluating.Remove(key); }
    }
}

public sealed class CfdReader
{
    internal readonly ViewSession Session;
    internal readonly ObjectData Data;
    private Dictionary<int, object?>? _results;
    private object? _view;
    internal CfdReader(ViewSession session, ObjectData data) { Session = session; Data = data; }
    public string Id => Data.Id ?? throw new InvalidOperationException("Inline data has no record identity.");
    internal object View
    {
        get { lock (Session.Sync) return _view ??= Data.Type.Create(this); }
    }
    internal object For(string dimension, string variant)
        => Session.Context.For(Data.Record ?? throw new InvalidOperationException("Only records have dimension views."), Session.Selection, dimension, variant);
    internal IReadOnlyList<string> Variants(string dimension) => Session.Context.DimensionVariants(dimension);
    internal bool HasVariant(string field, string variant)
    {
        var ordinal = Data.Type.FindOrdinal(field);
        if (ordinal < 0 || Data.Type.Fields[ordinal].Dimension == null) throw new ArgumentException($"Field `{field}` is not bound to a dimension.", nameof(field));
        return Data.Overrides != null && Data.Overrides.TryGetValue(ordinal, out var values) && values.ContainsKey(variant);
    }
    public T Get<T>(string field)
    {
        if (field == "id" && Data.Id != null) return (T)(object)Data.Id;
        var ordinal = Data.Type.FindOrdinal(field);
        if (ordinal < 0) throw LoadContext.Error("CFD-FIELD", $"unknown field `{field}`", Data.Path, Data.Span);
        return Get<T>(ordinal);
    }
    public T Get<T>(int ordinal) => (T)Read(ordinal)!;
    internal BoundField Source(int ordinal)
    {
        if ((uint)ordinal >= (uint)Data.Fields.Length) throw new ArgumentOutOfRangeException(nameof(ordinal));
        var dimension = Data.Type.Fields[ordinal].Dimension;
        if (dimension != null && Session.Selection.TryGet(dimension, out var variant) && Data.Overrides != null
            && Data.Overrides.TryGetValue(ordinal, out var values) && values.TryGetValue(variant, out var value)) return value;
        return Data.Fields[ordinal];
    }
    internal object? Read(int ordinal)
    {
        var source = Source(ordinal);
        if (source.Value.IsFixed) return source.Value.Read(this);
        lock (Session.Sync)
        {
            if (_results != null && _results.TryGetValue(ordinal, out var cached)) return cached;
            var value = Session.Evaluate(this, ordinal, source);
            (_results ??= new Dictionary<int, object?>()).Add(ordinal, value);
            return value;
        }
    }
}
}
