using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Coflow.Loader
{
// 固定值在绑定时构造一次；上下文表达式只保存必要的计算与校验逻辑。
internal abstract class BoundValue
{
    internal abstract bool IsFixed { get; }
    internal abstract object? Read(CfdReader reader);
    internal abstract void Validate(CfdReader reader);
    internal virtual CfdReader? Traverse(CfdReader reader) => null;
}
internal sealed class BoundValue<T> : BoundValue
{
    internal readonly T Fixed;
    private readonly object? _boxed;
    private readonly Func<CfdReader, T>? _evaluate;
    private readonly Action<CfdReader>? _validate;
    private readonly Func<CfdReader, CfdReader>? _traverse;
    internal BoundValue(T value, Func<CfdReader, CfdReader>? traverse = null) { Fixed = value; _boxed = value; _traverse = traverse; }
    internal BoundValue(Func<CfdReader, T> evaluate, Action<CfdReader>? validate = null, Func<CfdReader, CfdReader>? traverse = null)
    { Fixed = default!; _evaluate = evaluate; _validate = validate; _traverse = traverse; }
    internal override bool IsFixed => _evaluate == null;
    internal T Get(CfdReader reader)
    {
        if (_evaluate == null) return Fixed;
        lock (reader.Session.Sync) return _evaluate(reader);
    }
    internal override object? Read(CfdReader reader) => IsFixed ? _boxed : Get(reader);
    internal override void Validate(CfdReader reader)
    {
        if (_validate != null) _validate(reader);
        else if (!IsFixed) Get(reader);
    }
    internal override CfdReader? Traverse(CfdReader reader) => _traverse?.Invoke(reader);
}
internal sealed class BindingScope
{
    internal BindingScope(CfdType type, string path) { Type = type; Path = path; }
    internal CfdType Type { get; }
    internal string Path { get; }
    internal CfdLoadException Error(CfdValueNode node, string code, string message) => LoadContext.Error(code, message, Path, node.Span);
}

// 集合视图共享已绑定元素；只在实际读取元素时传播上下文，不复制整个引用集合。
internal sealed class ContextList<T> : IReadOnlyList<T>
{
    private readonly BoundValue<T>[] _items;
    private readonly CfdReader _reader;
    internal ContextList(BoundValue<T>[] items, CfdReader reader) { _items = items; _reader = reader; }
    public int Count => _items.Length;
    public T this[int index] => _items[index].Get(_reader);
    public IEnumerator<T> GetEnumerator() { for (var i = 0; i < Count; i++) yield return this[i]; }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
internal sealed class ContextDictionary<K, V> : IReadOnlyDictionary<K, V> where K : notnull
{
    private readonly Dictionary<K, int> _index;
    private readonly BoundValue<V>[] _values;
    private readonly CfdReader _reader;
    internal ContextDictionary(Dictionary<K, int> index, BoundValue<V>[] values, CfdReader reader)
    { _index = index; _values = values; _reader = reader; }
    public int Count => _index.Count;
    public IEnumerable<K> Keys => _index.Keys;
    public IEnumerable<V> Values => _index.Values.Select(index => _values[index].Get(_reader));
    public V this[K key] => _values[_index[key]].Get(_reader);
    public bool ContainsKey(K key) => _index.ContainsKey(key);
    public bool TryGetValue(K key, out V value)
    {
        if (_index.TryGetValue(key, out var index)) { value = _values[index].Get(_reader); return true; }
        value = default!; return false;
    }
    public IEnumerator<KeyValuePair<K, V>> GetEnumerator()
    { foreach (var pair in _index) yield return new KeyValuePair<K, V>(pair.Key, _values[pair.Value].Get(_reader)); }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
}
