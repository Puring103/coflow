using System.Threading.Tasks;
using System.Threading;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System;
namespace Coflow.Loader
{

using System.ComponentModel;

internal sealed class CfdDocument
{
    public CfdDocument(
        string path,
        IReadOnlyList<CfdRecordNode> records,
        IReadOnlyList<CfdDimensionBlock> dimensions)
    {
        Path = path;
        Records = records;
        Dimensions = dimensions;
    }

    public string Path { get; }
    public IReadOnlyList<CfdRecordNode> Records { get; }
    internal IReadOnlyList<CfdDimensionBlock> Dimensions { get; }
}

[EditorBrowsable(EditorBrowsableState.Never)]
public sealed class CfdRecordNode
{
    internal CfdRecordNode(
        string id,
        string declaredType,
        IReadOnlyList<CfdFieldNode> fields,
        CfdSpan span,
        string? groupType = null)
    {
        Id = id;
        DeclaredType = declaredType;
        Fields = fields;
        Span = span;
        GroupType = groupType;
    }

    public string Id { get; }
    public string DeclaredType { get; }
    public IReadOnlyList<CfdFieldNode> Fields { get; }
    public CfdSpan Span { get; }
    public string? GroupType { get; }
}

[EditorBrowsable(EditorBrowsableState.Never)]
public sealed class CfdFieldNode
{
    internal CfdFieldNode(string name, CfdValueNode value, CfdSpan span)
    {
        Name = name;
        Value = value;
        Span = span;
    }

    public string Name { get; }
    public CfdValueNode Value { get; }
    public CfdSpan Span { get; }
}

internal sealed class CfdEntryNode
{
    public CfdEntryNode(CfdValueNode key, CfdValueNode value, CfdSpan span)
    {
        Key = key;
        Value = value;
        Span = span;
    }

    public CfdValueNode Key { get; }
    public CfdValueNode Value { get; }
    public CfdSpan Span { get; }
}

[EditorBrowsable(EditorBrowsableState.Never)]
public abstract class CfdValueNode
{
    internal CfdValueNode(CfdSpan span) => Span = span;
    public CfdSpan Span { get; }
}

// 生成器提供已解析的枚举默认值，组合 flag 不依赖虚构的成员名称。
internal sealed class CfdEnumDefaultValue : CfdValueNode
{
    internal CfdEnumDefaultValue(string type, long value, CfdSpan span) : base(span)
    { Type = type; Value = value; }
    internal string Type { get; }
    internal long Value { get; }
}

internal sealed class CfdInvalidValue : CfdValueNode
{
    internal CfdInvalidValue(CfdSpan span) : base(span) { }
}

internal sealed class CfdNoneValue : CfdValueNode
{
    public CfdNoneValue(CfdSpan span) : base(span) { }
}




internal sealed class CfdSomeValue : CfdValueNode
{
    internal CfdSomeValue(CfdValueNode value, CfdSpan span) : base(span) => Value = value;
    internal CfdValueNode Value { get; }
}

internal sealed class CfdScalarValue : CfdValueNode
{
    public CfdScalarValue(string value, CfdSpan span, int? numericRank = null) : base(span) { Value = value; NumericRank = numericRank; }
    public string Value { get; }
    // 具名常量携带声明精度，源码数字字面量由消费位置决定精度。
    internal int? NumericRank { get; }
}


internal sealed class CfdStringValue : CfdValueNode
{
    public CfdStringValue(string value, CfdSpan span) : base(span) => Value = value;
    public string Value { get; }
}

internal sealed class CfdFormattedStringValue : CfdValueNode
{
    public CfdFormattedStringValue(string source, IReadOnlyList<CfdFormatSegment> segments, CfdSpan span)
        : base(span)
    {
        Source = source;
        Segments = segments;
    }

    public string Source { get; }
    public IReadOnlyList<CfdFormatSegment> Segments { get; }
}


internal abstract record CfdFormatSegment;

internal sealed record CfdFormatText(string Text) : CfdFormatSegment;

internal sealed record CfdFormatReference(
    string? TypeName,
    string? Id,
    IReadOnlyList<string> Path) : CfdFormatSegment;

internal sealed class CfdBitExpressionValue : CfdValueNode
{
    public CfdBitExpressionValue(CfdBitExpression expression, CfdSpan span) : base(span) => Expression = expression;
    public CfdBitExpression Expression { get; }
}

internal sealed class CfdBitExpression
{
    private CfdBitExpression(CfdBitExpressionKind kind, CfdSpan span)
    {
        Kind = kind;
        Span = span;
        Depth = kind is CfdBitExpressionKind.Binary binary ? 1 + Math.Max(binary.Left.Depth, binary.Right.Depth) : 1;
    }

    internal int Depth { get; }
    public CfdBitExpressionKind Kind { get; }
    public CfdSpan Span { get; }

    public static CfdBitExpression Value(string value, CfdSpan span) =>
        new(new CfdBitExpressionKind.Value(value), span);

    public static CfdBitExpression Binary(
        CfdBitOperator operation,
        CfdBitExpression left,
        CfdBitExpression right,
        CfdSpan span) =>
        new(new CfdBitExpressionKind.Binary(operation, left, right), span);

    internal CfdBitExpression WithSpan(CfdSpan span) => new(Kind, span);
}

internal abstract record CfdBitExpressionKind
{
    private CfdBitExpressionKind() { }

    public sealed record Value(string Text) : CfdBitExpressionKind;

    public sealed record Binary(
        CfdBitOperator Operator,
        CfdBitExpression Left,
        CfdBitExpression Right) : CfdBitExpressionKind;
}

internal enum CfdBitOperator
{
    Or,
    Xor,
    And,
}

internal sealed class CfdReferenceValue : CfdValueNode
{
    public CfdReferenceValue(string? typeName, string id, CfdSpan span) : base(span)
    {
        TypeName = typeName;
        Id = id;
    }

    public string? TypeName { get; }
    public string Id { get; }
}

internal sealed class CfdObjectValue : CfdValueNode
{
    public CfdObjectValue(string? declaredType, IReadOnlyList<CfdFieldNode> fields, CfdSpan span) : base(span)
    {
        DeclaredType = declaredType;
        Fields = fields;
    }

    public string? DeclaredType { get; }
    public IReadOnlyList<CfdFieldNode> Fields { get; }
}

internal sealed class CfdArrayValue : CfdValueNode
{
    public CfdArrayValue(IReadOnlyList<CfdValueNode> items, CfdSpan span) : base(span) => Items = items;
    public IReadOnlyList<CfdValueNode> Items { get; }
}

internal sealed class CfdDictionaryValue : CfdValueNode
{
    public CfdDictionaryValue(IReadOnlyList<CfdEntryNode> entries, CfdSpan span) : base(span) => Entries = entries;
    public IReadOnlyList<CfdEntryNode> Entries { get; }
}
}

namespace Coflow.Loader
{
internal sealed record CfdDimensionBlock(string Dimension, string Variant, IReadOnlyList<CfdRecordNode> Records, CfdSpan Span);
}
