mod annotations;
mod budget;
mod checks;
mod constants;
mod defaults;
mod entry;
mod enums;
mod inferred_type;
mod inheritance;
mod lower;
mod state;
mod symbols;
mod types;

pub use entry::{build_schema, build_schema_with_limits};

use self::checks::CheckTypeAnalyzer;
use self::state::{CheckInfo, ConstInfo, EnumInfo, FieldInfo, Symbol, TypeAliasInfo, TypeInfo};
use crate::module::{CftModuleSet, ModuleId};
use crate::schema::{
    CftConst, CftEnum, CftTopLevelCheck, CftType, CheckName, ConstName, EnumName, TypeName,
};
use crate::source::Span;
use crate::{CftDiagnostic, CftErrorCode};
use std::collections::BTreeMap;
use std::ops::Deref;

#[derive(Debug, Clone, Default)]
pub(in crate::schema) struct SchemaDeclarations {
    pub(super) consts: BTreeMap<ConstName, CftConst>,
    pub(super) types: BTreeMap<TypeName, CftType>,
    pub(super) enums: BTreeMap<EnumName, CftEnum>,
    pub(super) checks: BTreeMap<CheckName, CftTopLevelCheck>,
    pub(super) sources: BTreeMap<ModuleId, crate::schema::CftSchemaSource>,
}

pub(super) struct SymbolTable<'a> {
    modules: &'a CftModuleSet,
    diagnostics: Vec<CftDiagnostic>,
    symbols: BTreeMap<String, Symbol>,
    consts: BTreeMap<String, ConstInfo<'a>>,
    types: BTreeMap<String, TypeInfo<'a>>,
    aliases: BTreeMap<String, TypeAliasInfo<'a>>,
    enums: BTreeMap<String, EnumInfo<'a>>,
    checks: BTreeMap<String, CheckInfo<'a>>,
}

pub(super) struct ResolvedTypes<'a> {
    symbol_table: SymbolTable<'a>,
    diagnostics: Vec<CftDiagnostic>,
    declared_field_types: BTreeMap<(ModuleId, usize, usize), inferred_type::InferredType>,
    full_fields: BTreeMap<String, BTreeMap<String, FieldInfo>>,
    inheritance_chains: BTreeMap<String, Vec<String>>,
    resolved_aliases: BTreeMap<String, inferred_type::InferredType>,
}

pub(super) struct ResolvedValues<'a> {
    type_state: ResolvedTypes<'a>,
    constants: BTreeMap<String, (crate::schema::CftValueType, crate::schema::CftConstValue)>,
    defaults: BTreeMap<(ModuleId, usize, usize), crate::schema::CftConstValue>,
}

struct ValueResolver<'s, 'a> {
    resolved_types: &'s ResolvedTypes<'a>,
    resolved_constants:
        BTreeMap<String, (crate::schema::CftValueType, crate::schema::CftConstValue)>,
    resolved_defaults: BTreeMap<(ModuleId, usize, usize), crate::schema::CftConstValue>,
    diagnostics: Vec<CftDiagnostic>,
}

pub(super) struct ValidatedSchema<'a> {
    resolved_values: ResolvedValues<'a>,
    quantifier_bindings:
        BTreeMap<(ModuleId, usize, usize), crate::schema::CftSchemaQuantifierBindings>,
    check_dimensions:
        BTreeMap<(ModuleId, usize, usize), BTreeMap<crate::DimensionName, Vec<usize>>>,
    check_statement_dependencies:
        BTreeMap<(ModuleId, usize, usize), Vec<crate::schema::CheckStatementDependencies>>,
}

impl<'a> SymbolTable<'a> {
    fn new(modules: &'a CftModuleSet) -> Self {
        Self {
            modules,
            diagnostics: Vec::new(),
            symbols: BTreeMap::new(),
            consts: BTreeMap::new(),
            types: BTreeMap::new(),
            aliases: BTreeMap::new(),
            enums: BTreeMap::new(),
            checks: BTreeMap::new(),
        }
    }

    pub(super) fn push_diag(
        &mut self,
        code: CftErrorCode,
        module: &ModuleId,
        span: Span,
        message: impl Into<String>,
    ) {
        self.diagnostics
            .push(CftDiagnostic::error(code, module.clone(), span, message));
    }
}

impl<'a> ResolvedTypes<'a> {
    fn new(symbol_table: SymbolTable<'a>) -> Self {
        Self {
            symbol_table,
            diagnostics: Vec::new(),
            declared_field_types: BTreeMap::new(),
            full_fields: BTreeMap::new(),
            inheritance_chains: BTreeMap::new(),
            resolved_aliases: BTreeMap::new(),
        }
    }

    fn push_diag(
        &mut self,
        code: CftErrorCode,
        module: &ModuleId,
        span: Span,
        message: impl Into<String>,
    ) {
        self.diagnostics
            .push(CftDiagnostic::error(code, module.clone(), span, message));
    }

    fn push_budget_error(
        &mut self,
        error: crate::limits::BudgetExceeded,
        module: &ModuleId,
        span: Span,
    ) {
        self.push_diag(
            CftErrorCode::SchemaStructureLimitExceeded,
            module,
            span,
            error.to_string(),
        );
    }
}

impl<'a> Deref for ResolvedTypes<'a> {
    type Target = SymbolTable<'a>;

    fn deref(&self) -> &Self::Target {
        &self.symbol_table
    }
}

impl<'a> ResolvedValues<'a> {
    fn resolve(types: ResolvedTypes<'a>) -> (Self, Vec<CftDiagnostic>) {
        let (resolved_constants, resolved_defaults, diagnostics) = {
            let mut resolver = ValueResolver {
                resolved_types: &types,
                resolved_constants: BTreeMap::new(),
                resolved_defaults: BTreeMap::new(),
                diagnostics: Vec::new(),
            };
            resolver.resolve_constants();
            resolver.validate_defaults();
            (
                resolver.resolved_constants,
                resolver.resolved_defaults,
                resolver.diagnostics,
            )
        };
        (
            Self {
                type_state: types,
                constants: resolved_constants,
                defaults: resolved_defaults,
            },
            diagnostics,
        )
    }
}

impl<'a> Deref for ResolvedValues<'a> {
    type Target = ResolvedTypes<'a>;

    fn deref(&self) -> &Self::Target {
        &self.type_state
    }
}

impl<'a> Deref for ValueResolver<'_, 'a> {
    type Target = ResolvedTypes<'a>;

    fn deref(&self) -> &Self::Target {
        self.resolved_types
    }
}

impl ValueResolver<'_, '_> {
    fn push_diag(
        &mut self,
        code: CftErrorCode,
        module: &ModuleId,
        span: Span,
        message: impl Into<String>,
    ) {
        self.diagnostics
            .push(CftDiagnostic::error(code, module.clone(), span, message));
    }
}

impl<'a> ValidatedSchema<'a> {
    #[expect(
        clippy::too_many_lines,
        reason = "按语言或命令分支集中处理，保持分派与各分支语义可直接核对。"
    )]
    fn validate(values: ResolvedValues<'a>) -> (Self, Vec<CftDiagnostic>) {
        let mut quantifier_bindings = BTreeMap::new();
        let mut check_dimensions = BTreeMap::new();
        let mut check_statement_dependencies = BTreeMap::new();
        let mut diagnostics = Vec::new();
        for info in values.types.values() {
            // 只在本次声明处报告冲突，并关联最早的父类型/本地声明位置。
            let mut names = BTreeMap::new();
            for ancestor in values
                .inheritance_chains
                .get(&info.name)
                .into_iter()
                .flatten()
                .filter(|name| *name != &info.name)
            {
                if let Some(owner) = values.types.get(ancestor) {
                    for check in &owner.def.checks {
                        if let Some(name) = &check.name {
                            names
                                .entry(name.clone())
                                .or_insert_with(|| (owner.module.clone(), check.name_span));
                        }
                    }
                }
            }
            for check in &info.def.checks {
                if let Some(name) = &check.name {
                    if crate::is_cft_reserved_identifier(name) {
                        diagnostics.push(CftDiagnostic::error(
                            CftErrorCode::ReservedIdentifier,
                            info.module.clone(),
                            check.name_span,
                            format!("`{name}` is a reserved identifier"),
                        ));
                    }
                    if let Some((module, span)) = names.get(name) {
                        diagnostics.push(
                            CftDiagnostic::error(
                                CftErrorCode::DuplicateCheckBlock,
                                info.module.clone(),
                                check.name_span,
                                format!(
                                    "duplicate check rule `{}` in inheritance chain of `{}`",
                                    name, info.name
                                ),
                            )
                            .with_related(
                                module.clone(),
                                *span,
                                "first rule declaration is here",
                            ),
                        );
                    } else {
                        names.insert(name.clone(), (info.module.clone(), check.name_span));
                    }
                }
                if check.stmts.is_empty() {
                    diagnostics.push(CftDiagnostic::error(
                        CftErrorCode::InvalidCheckStatement,
                        info.module.clone(),
                        check.span,
                        "check rule must contain at least one statement",
                    ));
                }
                let analysis = CheckTypeAnalyzer::new(&values, info)
                    .check_root_stmts(&check.stmts, check.message.as_ref());
                check_dimensions.insert(
                    (info.module.clone(), check.span.start, check.span.end),
                    analysis.dimensions,
                );
                check_statement_dependencies.insert(
                    (info.module.clone(), check.span.start, check.span.end),
                    analysis.dependencies,
                );
                quantifier_bindings.extend(analysis.quantifier_bindings);
                diagnostics.extend(analysis.diagnostics);
            }
        }
        for info in values.checks.values() {
            if info.def.block.stmts.is_empty() {
                diagnostics.push(CftDiagnostic::error(
                    CftErrorCode::InvalidCheckStatement,
                    info.module.clone(),
                    info.def.block.span,
                    "check rule must contain at least one statement",
                ));
            }
            let analysis = CheckTypeAnalyzer::top_level(&values, info.module.clone())
                .check_root_stmts(&info.def.block.stmts, info.def.block.message.as_ref());
            check_dimensions.insert(
                (
                    info.module.clone(),
                    info.def.block.span.start,
                    info.def.block.span.end,
                ),
                analysis.dimensions,
            );
            check_statement_dependencies.insert(
                (
                    info.module.clone(),
                    info.def.block.span.start,
                    info.def.block.span.end,
                ),
                analysis.dependencies,
            );
            quantifier_bindings.extend(analysis.quantifier_bindings);
            diagnostics.extend(analysis.diagnostics);
        }
        (
            Self {
                resolved_values: values,
                quantifier_bindings,
                check_dimensions,
                check_statement_dependencies,
            },
            diagnostics,
        )
    }
}

impl<'a> Deref for ValidatedSchema<'a> {
    type Target = ResolvedValues<'a>;

    fn deref(&self) -> &Self::Target {
        &self.resolved_values
    }
}
