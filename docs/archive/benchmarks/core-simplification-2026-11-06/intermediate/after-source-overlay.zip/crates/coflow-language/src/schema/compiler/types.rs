use super::inferred_type::{is_valid_dict_key, InferredType};
use super::state::{FieldInfo, SymbolKind};
use super::ResolvedTypes;
use crate::diagnostics::{CftDiagnostic, CftErrorCode};
use crate::module::ModuleId;
use crate::source::Span;
use crate::syntax::ast::{TypeKind, TypeRef, TypeRefKind};
use crate::CftValueType;
use std::collections::BTreeMap;

impl ResolvedTypes<'_> {
    pub(super) fn validate_type_aliases(&mut self) {
        let names = self.aliases.keys().cloned().collect::<Vec<_>>();
        let mut visiting = Vec::new();
        for name in names {
            let _ = self.resolve_type_alias(&name, &mut visiting);
        }
    }

    fn resolve_type_alias(&mut self, name: &str, visiting: &mut Vec<String>) -> InferredType {
        if let Some(resolved) = self.resolved_aliases.get(name) {
            return resolved.clone();
        }
        let Some(info) = self.aliases.get(name).cloned() else {
            return InferredType::Unknown;
        };
        if let Some(start) = visiting.iter().position(|entry| entry == name) {
            let mut cycle = visiting[start..].to_vec();
            cycle.push(name.to_string());
            self.push_diag(
                CftErrorCode::TypeAliasCycle,
                &info.module,
                info.def.target.span,
                format!("type alias cycle: {}", cycle.join(" -> ")),
            );
            return InferredType::Unknown;
        }

        visiting.push(name.to_string());
        let resolved = self.resolve_alias_target(&info.module, &info.def.target, visiting);
        visiting.pop();
        self.resolved_aliases
            .insert(name.to_string(), resolved.clone());
        resolved
    }

    // 类型变体集中递归解析，避免 alias 与字段类型走出不同规则。
    #[allow(clippy::too_many_lines)]
    fn resolve_alias_target(
        &mut self,
        module: &ModuleId,
        ty: &TypeRef,
        visiting: &mut Vec<String>,
    ) -> InferredType {
        match &ty.kind {
            TypeRefKind::Int => InferredType::int(),
            TypeRefKind::Long => InferredType::long(),
            TypeRefKind::Double => InferredType::double(),
            TypeRefKind::Float => InferredType::float(),
            TypeRefKind::Bool => InferredType::bool(),
            TypeRefKind::String => InferredType::string(),
            TypeRefKind::Named(name) => {
                let resolved_name = name.clone();
                match self.symbols.get(&resolved_name).map(|symbol| symbol.kind) {
                    Some(SymbolKind::Type) => {
                        if self.type_is_singleton(&resolved_name) {
                            self.push_diag(
                                CftErrorCode::InvalidAnnotatedFieldType,
                                module,
                                ty.span,
                                "singleton type cannot be used as a value type",
                            );
                        }
                        if self.type_is_table(&resolved_name) {
                            self.push_diag(
                                CftErrorCode::InvalidAnnotatedFieldType,
                                module,
                                ty.span,
                                format!("table type `{resolved_name}` must be written as `&{resolved_name}`"),
                            );
                        }
                        Self::named_value_type(&resolved_name)
                    }
                    Some(SymbolKind::Enum) => {
                        InferredType::enum_value(crate::EnumName::from_validated(resolved_name))
                    }
                    Some(SymbolKind::TypeAlias) => {
                        self.resolve_type_alias(&resolved_name, visiting)
                    }
                    Some(_) => {
                        let symbol = self.symbols.get(&resolved_name).cloned();
                        let mut diagnostic = CftDiagnostic::error(
                            CftErrorCode::UnknownNamedType,
                            module.clone(),
                            ty.span,
                            format!("alias target `{resolved_name}` is not a type or enum"),
                        );
                        if let Some(symbol) = symbol {
                            diagnostic = diagnostic.with_related(
                                symbol.module,
                                symbol.span,
                                "name is defined here",
                            );
                        }
                        self.diagnostics.push(diagnostic);
                        InferredType::Unknown
                    }
                    None => {
                        self.push_diag(
                            CftErrorCode::UnknownNamedType,
                            module,
                            ty.span,
                            format!("unknown alias target `{resolved_name}`"),
                        );
                        InferredType::Unknown
                    }
                }
            }
            TypeRefKind::Ref(inner) => {
                // 先解析别名依赖，再验证显式引用目标；裸 table 仅能出现在 & 内部。
                if let TypeRefKind::Named(name) = &inner.kind {
                    if self.aliases.contains_key(name) {
                        self.resolve_type_alias(name, visiting);
                    }
                }
                let mut diagnostics = Vec::new();
                let resolved = self.validate_reference_type(module, inner, &mut diagnostics);
                self.diagnostics.extend(diagnostics);
                resolved
            }
            TypeRefKind::Array(inner) => {
                InferredType::array(self.resolve_alias_target(module, inner, visiting))
            }
            TypeRefKind::Dict(key, value) => {
                let key_ty = self.resolve_alias_target(module, key, visiting);
                if !key_ty.is_unknown() && !is_valid_dict_key(&key_ty) {
                    self.push_diag(
                        CftErrorCode::InvalidDictKeyType,
                        module,
                        key.span,
                        "dict key type must be string, int, or enum",
                    );
                }
                InferredType::dict(key_ty, self.resolve_alias_target(module, value, visiting))
            }
            TypeRefKind::Option(inner) => {
                InferredType::option(self.resolve_alias_target(module, inner, visiting))
            }
        }
    }

    pub(super) fn validate_type_headers(&mut self) {
        let mut diagnostics = Vec::new();
        for info in self.types.values() {
            if info.def.kind == TypeKind::Singleton && info.def.is_abstract {
                diagnostics.push(CftDiagnostic::error(
                    CftErrorCode::SingletonOnAbstractType,
                    info.module.clone(),
                    info.def.span,
                    "singleton must be concrete",
                ));
            }
            if info.def.is_abstract && info.def.is_sealed {
                let span = info
                    .def
                    .abstract_span
                    .unwrap_or(info.def.span)
                    .join(info.def.sealed_span.unwrap_or(info.def.span));
                diagnostics.push(CftDiagnostic::error(
                    CftErrorCode::ConflictingTypeModifiers,
                    info.module.clone(),
                    span,
                    "abstract and sealed modifiers cannot be combined",
                ));
            }
            if let Some(parent) = &info.def.parent {
                let parent_name = parent.name.clone();
                match self.symbols.get(&parent_name) {
                    Some(symbol) if symbol.kind == SymbolKind::Type => {
                        if let Some(parent_info) = self.types.get(&parent_name) {
                            let valid = match info.def.kind {
                                TypeKind::Data => parent_info.def.kind == TypeKind::Data,
                                TypeKind::Table | TypeKind::Singleton => {
                                    parent_info.def.kind == TypeKind::Table
                                }
                            };
                            if !valid {
                                diagnostics.push(CftDiagnostic::error(
                                    CftErrorCode::ParentMustBeType,
                                    info.module.clone(),
                                    parent.span,
                                    "data inherits data; table and singleton inherit table",
                                ));
                            }
                        }
                    }
                    Some(symbol) => {
                        diagnostics.push(
                            CftDiagnostic::error(
                                CftErrorCode::ParentMustBeType,
                                info.module.clone(),
                                parent.span,
                                "parent must be a type",
                            )
                            .with_related(
                                symbol.module.clone(),
                                symbol.span,
                                "name is defined here",
                            ),
                        );
                    }
                    None => {
                        diagnostics.push(CftDiagnostic::error(
                            CftErrorCode::UnknownNamedType,
                            info.module.clone(),
                            parent.span,
                            format!("unknown parent type `{parent_name}`"),
                        ));
                    }
                }
            }
        }
        self.diagnostics.extend(diagnostics);
    }

    pub(super) fn validate_field_shapes(&mut self) {
        let mut diagnostics = Vec::new();
        let mut declared_field_types = BTreeMap::new();
        for info in self.types.values() {
            let mut fields: BTreeMap<String, Span> = BTreeMap::new();
            for field in &info.def.fields {
                if crate::is_cft_reserved_identifier(&field.name)
                    || (info.def.kind != TypeKind::Data && field.name == "id")
                {
                    diagnostics.push(CftDiagnostic::error(
                        CftErrorCode::ReservedIdentifier,
                        info.module.clone(),
                        field.name_span,
                        format!("`{}` is a reserved identifier", field.name),
                    ));
                }
                if let Some(first_span) = fields.get(&field.name) {
                    diagnostics.push(
                        CftDiagnostic::error(
                            CftErrorCode::DuplicateFieldName,
                            info.module.clone(),
                            field.name_span,
                            format!("duplicate field `{}`", field.name),
                        )
                        .with_related(
                            info.module.clone(),
                            *first_span,
                            "first field is here",
                        ),
                    );
                } else {
                    fields.insert(field.name.clone(), field.name_span);
                }
                let resolved = self.validate_field_type(&info.module, &field.ty, &mut diagnostics);
                declared_field_types.insert(
                    (info.module.clone(), field.span.start, field.span.end),
                    resolved,
                );
            }
        }
        self.diagnostics.extend(diagnostics);
        self.declared_field_types = declared_field_types;
    }

    /// 声明类型只在字段校验阶段解析；继承、默认值和 lowering 共用同一结果。
    pub(super) fn declared_field_type(
        &self,
        module: &ModuleId,
        field: &crate::syntax::ast::FieldDef,
    ) -> &InferredType {
        &self.declared_field_types[&(module.clone(), field.span.start, field.span.end)]
    }

    pub(super) fn build_full_fields(&mut self) {
        self.full_fields = self
            .types
            .keys()
            .map(|name| {
                let mut map = BTreeMap::new();
                for info in self.ancestry_chain(name) {
                    for field in &info.def.fields {
                        let declared_ty = self.declared_field_type(&info.module, field).clone();
                        map.insert(
                            field.name.clone(),
                            FieldInfo {
                                declaring_type: crate::TypeName::from_validated(info.name.clone()),
                                inferred_type: declared_ty,
                                dimension: super::annotations::field_dimension_name(field),
                                span: field.span,
                            },
                        );
                    }
                }
                (name.clone(), map)
            })
            .collect();
    }

    /// 必填 object 字段必须能够有限展开；Option、集合和引用会终止默认创建路径。
    pub(super) fn validate_required_object_cycles(&mut self) {
        #[derive(Clone)]
        struct Edge {
            field: String,
            target: String,
            declaring_type: String,
            span: Span,
        }

        let graph = self
            .full_fields
            .iter()
            .map(|(owner, fields)| {
                let edges = fields
                    .iter()
                    .filter_map(|(name, field)| match &field.inferred_type {
                        InferredType::Value(CftValueType::Object(target)) => Some(Edge {
                            field: name.clone(),
                            target: target.to_string(),
                            declaring_type: field.declaring_type.to_string(),
                            span: field.span,
                        }),
                        _ => None,
                    })
                    .collect::<Vec<_>>();
                (owner.clone(), edges)
            })
            .collect::<BTreeMap<_, _>>();

        let mut states = BTreeMap::<String, u8>::new();
        for root in graph.keys() {
            if states.get(root).copied() == Some(2) {
                continue;
            }
            let mut nodes = vec![root.clone()];
            let mut incoming = Vec::<Edge>::new();
            let mut frames = vec![(root.clone(), 0usize)];
            states.insert(root.clone(), 1);

            while let Some((owner, next_edge)) = frames.last_mut() {
                let edges = graph.get(owner).map_or(&[][..], Vec::as_slice);
                let Some(edge) = edges.get(*next_edge).cloned() else {
                    let completed = owner.clone();
                    frames.pop();
                    nodes.pop();
                    if !frames.is_empty() {
                        incoming.pop();
                    }
                    states.insert(completed, 2);
                    continue;
                };
                *next_edge += 1;

                match states.get(&edge.target).copied() {
                    Some(1) => {
                        let start = nodes
                            .iter()
                            .position(|node| node == &edge.target)
                            .unwrap_or(0);
                        let mut cycle = incoming[start..]
                            .iter()
                            .map(|step| format!("{}.{}", nodes[start], step.field))
                            .collect::<Vec<_>>();
                        cycle.push(format!("{owner}.{}", edge.field));
                        cycle.push(edge.target.clone());
                        let module = self.types.get(&edge.declaring_type).map_or_else(
                            || self.types[owner].module.clone(),
                            |info| info.module.clone(),
                        );
                        self.diagnostics.push(CftDiagnostic::error(
                            CftErrorCode::RequiredObjectCycle,
                            module,
                            edge.span,
                            format!("required object field cycle: {}", cycle.join(" -> ")),
                        ));
                    }
                    Some(2) => {}
                    _ => {
                        states.insert(edge.target.clone(), 1);
                        nodes.push(edge.target.clone());
                        incoming.push(edge.clone());
                        frames.push((edge.target, 0));
                    }
                }
            }
        }
    }

    /// 为常量注解、引用目标等非字段入口解析类型，不重复产生已有诊断。
    /// 已声明字段直接消费 [`Self::declared_field_type`] 缓存的校验结果。
    pub(super) fn resolve_field_type(&self, ty: &TypeRef) -> InferredType {
        match &ty.kind {
            TypeRefKind::Int => InferredType::int(),
            TypeRefKind::Long => InferredType::long(),
            TypeRefKind::Double => InferredType::double(),
            TypeRefKind::Float => InferredType::float(),
            TypeRefKind::Bool => InferredType::bool(),
            TypeRefKind::String => InferredType::string(),
            TypeRefKind::Named(name) => {
                let name = name.clone();
                match self.symbols.get(&name) {
                    Some(symbol) if symbol.kind == SymbolKind::Type => {
                        Self::named_value_type(&name)
                    }
                    Some(symbol) if symbol.kind == SymbolKind::Enum => {
                        InferredType::enum_value(crate::EnumName::from_validated(name))
                    }
                    Some(symbol) if symbol.kind == SymbolKind::TypeAlias => self
                        .resolved_aliases
                        .get(&name)
                        .cloned()
                        .unwrap_or(InferredType::Unknown),
                    _ => InferredType::Unknown,
                }
            }
            TypeRefKind::Ref(inner) => match self.resolve_field_type(inner).object_name() {
                Some(name) if self.type_is_table(name) => InferredType::Value(
                    CftValueType::RecordRef(crate::TypeName::from_validated(name)),
                ),
                _ => InferredType::Unknown,
            },
            TypeRefKind::Array(inner) => InferredType::array(self.resolve_field_type(inner)),
            TypeRefKind::Dict(key, value) => {
                InferredType::dict(self.resolve_field_type(key), self.resolve_field_type(value))
            }
            TypeRefKind::Option(inner) => InferredType::option(self.resolve_field_type(inner)),
        }
    }

    /// 单次遍历字段类型，只读取已解析阶段，并把诊断写入本次校验的局部结果。
    // 字段类型诊断与解析分支逐项对应，集中保留完整错误上下文。
    #[allow(clippy::too_many_lines)]
    fn validate_field_type(
        &self,
        module: &ModuleId,
        ty: &TypeRef,
        diagnostics: &mut Vec<CftDiagnostic>,
    ) -> InferredType {
        let diagnostic =
            |code, span, message: String| CftDiagnostic::error(code, module.clone(), span, message);
        match &ty.kind {
            TypeRefKind::Int => InferredType::int(),
            TypeRefKind::Long => InferredType::long(),
            TypeRefKind::Double => InferredType::double(),
            TypeRefKind::Float => InferredType::float(),
            TypeRefKind::Bool => InferredType::bool(),
            TypeRefKind::String => InferredType::string(),
            TypeRefKind::Named(name) => {
                let resolved_name = name.clone();
                match self.symbols.get(&resolved_name) {
                    Some(symbol) if symbol.kind == SymbolKind::Type => {
                        if self.type_is_singleton(&resolved_name) {
                            diagnostics.push(diagnostic(
                                CftErrorCode::InvalidAnnotatedFieldType,
                                ty.span,
                                "singleton type cannot be used as a field type".into(),
                            ));
                        }
                        if self.type_is_table(&resolved_name) {
                            diagnostics.push(diagnostic(
                                CftErrorCode::InvalidAnnotatedFieldType,
                                ty.span,
                                format!("table type `{resolved_name}` must be written as `&{resolved_name}`"),
                            ));
                        }
                        Self::named_value_type(&resolved_name)
                    }
                    Some(symbol) if symbol.kind == SymbolKind::Enum => {
                        InferredType::enum_value(crate::EnumName::from_validated(resolved_name))
                    }
                    Some(symbol) if symbol.kind == SymbolKind::TypeAlias => self
                        .resolved_aliases
                        .get(&resolved_name)
                        .cloned()
                        .unwrap_or(InferredType::Unknown),
                    Some(symbol) => {
                        diagnostics.push(
                            diagnostic(
                                CftErrorCode::UnknownNamedType,
                                ty.span,
                                format!("field type `{resolved_name}` is not a type or enum"),
                            )
                            .with_related(
                                symbol.module.clone(),
                                symbol.span,
                                "name is defined here",
                            ),
                        );
                        InferredType::Unknown
                    }
                    None => {
                        diagnostics.push(diagnostic(
                            CftErrorCode::UnknownNamedType,
                            ty.span,
                            format!("unknown field type `{resolved_name}`"),
                        ));
                        InferredType::Unknown
                    }
                }
            }
            TypeRefKind::Ref(inner) => self.validate_reference_type(module, inner, diagnostics),
            TypeRefKind::Array(inner) => {
                InferredType::array(self.validate_field_type(module, inner, diagnostics))
            }
            TypeRefKind::Dict(key, value) => {
                let key_ty = self.validate_field_type(module, key, diagnostics);
                if !is_valid_dict_key(&key_ty) {
                    diagnostics.push(diagnostic(
                        CftErrorCode::InvalidDictKeyType,
                        key.span,
                        "dict key type must be string, int, or enum".into(),
                    ));
                }
                InferredType::dict(key_ty, self.validate_field_type(module, value, diagnostics))
            }
            TypeRefKind::Option(inner) => {
                InferredType::option(self.validate_field_type(module, inner, diagnostics))
            }
        }
    }

    // & 只允许指向 table；data 内联保存，singleton 通过唯一入口访问。
    fn validate_reference_type(
        &self,
        module: &ModuleId,
        inner: &TypeRef,
        diagnostics: &mut Vec<CftDiagnostic>,
    ) -> InferredType {
        let resolved = self.resolve_field_type(inner);
        if let Some(name) = resolved.object_name() {
            if self.type_is_table(name) {
                return InferredType::Value(CftValueType::RecordRef(
                    crate::TypeName::from_validated(name),
                ));
            }
        }
        if resolved.is_unknown() {
            self.validate_field_type(module, inner, diagnostics);
        }
        diagnostics.push(CftDiagnostic::error(
            CftErrorCode::InvalidAnnotatedFieldType,
            module.clone(),
            inner.span,
            "reference target must be a table type",
        ));
        InferredType::Unknown
    }

    fn named_value_type(name: &str) -> InferredType {
        InferredType::object(crate::TypeName::from_validated(name))
    }

    fn type_is_table(&self, name: &str) -> bool {
        self.types
            .get(name)
            .is_some_and(|info| info.def.kind == TypeKind::Table)
    }

    fn type_is_singleton(&self, name: &str) -> bool {
        self.types
            .get(name)
            .is_some_and(|info| info.def.kind == TypeKind::Singleton)
    }
}
