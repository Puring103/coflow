use super::{Parsed, Parser};
use crate::diagnostics::{CftDiagnostics, CftErrorCode};
use crate::limits::StructureKind;
use crate::source::Span;
use crate::syntax::ast::{CheckExpr, CheckExprKind, CheckFormatSegment, NameRef, TypePredicate};
use crate::syntax::lexer::TokenKind;

impl Parser<'_> {
    #[allow(clippy::too_many_lines)]
    pub(super) fn parse_postfix_expr(&mut self) -> Result<Parsed<CheckExpr>, CftDiagnostics> {
        let mut expr = self.parse_primary_expr()?;
        loop {
            if let Some(opener) = self.eat(&TokenKind::LParen) {
                let CheckExpr { kind, span } = expr.value;
                let name = match kind {
                    CheckExprKind::Name(name) => name,
                    CheckExprKind::StaticPath(path) => path.canonical(),
                    _ => {
                        return self.err(
                            CftErrorCode::UnexpectedToken,
                            "only named functions can be called",
                        );
                    }
                };
                let call_name = NameRef { name, span };
                let (args, end) = self.nested(StructureKind::CheckAst, opener, |parser| {
                    let mut args = Vec::new();
                    while !parser.at(&TokenKind::RParen) {
                        if parser.at(&TokenKind::Eof) {
                            return parser
                                .err(CftErrorCode::UnexpectedEof, "unterminated function call");
                        }
                        args.push(parser.parse_or_expr()?);
                        if parser.eat(&TokenKind::Comma).is_none() {
                            break;
                        }
                    }
                    let end = parser
                        .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                        .end;
                    Ok((args, end))
                })?;
                let depths = args.iter().map(|arg| arg.depth).collect::<Vec<_>>();
                expr = self.node(StructureKind::CheckAst, opener, depths, || CheckExpr {
                    span: Span::new(call_name.span.start, end),
                    kind: if call_name.name == "records" && args.len() == 1 {
                        let argument = &args[0].value;
                        match &argument.kind {
                            CheckExprKind::Name(name) => CheckExprKind::Records {
                                type_name: NameRef {
                                    name: name.clone(),
                                    span: argument.span,
                                },
                            },
                            CheckExprKind::StaticPath(path) => CheckExprKind::Records {
                                type_name: NameRef {
                                    name: path.canonical(),
                                    span: argument.span,
                                },
                            },
                            _ => CheckExprKind::Call {
                                name: call_name,
                                args: args.into_iter().map(|arg| arg.value).collect(),
                            },
                        }
                    } else {
                        CheckExprKind::Call {
                            name: call_name,
                            args: args.into_iter().map(|arg| arg.value).collect(),
                        }
                    },
                })?;
            } else if let Some(dot) = self.eat(&TokenKind::Dot) {
                let name = self.expect_ident()?;
                if let Some(opener) = self.eat(&TokenKind::LParen) {
                    let (args, end) = self.nested(StructureKind::CheckAst, opener, |parser| {
                        let mut args = Vec::new();
                        if !parser.at(&TokenKind::RParen) {
                            loop {
                                args.push(parser.parse_or_expr()?);
                                if parser.eat(&TokenKind::Comma).is_none() {
                                    break;
                                }
                            }
                        }
                        let end = parser
                            .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                            .end;
                        Ok((args, end))
                    })?;
                    let span = Span::new(expr.value.span.start, end);
                    let depths = std::iter::once(expr.depth)
                        .chain(args.iter().map(|arg| arg.depth))
                        .collect::<Vec<_>>();
                    expr = self.node(StructureKind::CheckAst, opener, depths, || CheckExpr {
                        span,
                        kind: CheckExprKind::MethodCall {
                            receiver: Box::new(expr.value),
                            name,
                            args: args.into_iter().map(|arg| arg.value).collect(),
                        },
                    })?;
                } else {
                    let span = Span::new(expr.value.span.start, name.span.end);
                    let depth = expr.depth;
                    expr = self.node(StructureKind::CheckAst, dot, [depth], || CheckExpr {
                        span,
                        kind: CheckExprKind::Field {
                            expr: Box::new(expr.value),
                            name,
                        },
                    })?;
                }
            } else if let Some(opener) = self.eat(&TokenKind::LBracket) {
                let (index, end) = self.nested(StructureKind::CheckAst, opener, |parser| {
                    let index = parser.parse_or_expr()?;
                    let end = parser
                        .expect_simple(&TokenKind::RBracket, CftErrorCode::ExpectedToken)?
                        .end;
                    Ok((index, end))
                })?;
                let span = Span::new(expr.value.span.start, end);
                let depths = [expr.depth, index.depth];
                expr = self.node(StructureKind::CheckAst, opener, depths, || CheckExpr {
                    span,
                    kind: CheckExprKind::Index {
                        expr: Box::new(expr.value),
                        index: Box::new(index.value),
                    },
                })?;
            } else {
                break;
            }
        }
        Ok(expr)
    }

    fn parse_primary_expr(&mut self) -> Result<Parsed<CheckExpr>, CftDiagnostics> {
        let token_span = self.peek().span;
        match &mut self.tokens[self.pos].kind {
            TokenKind::Int(value) => {
                let value = *value;
                self.bump();
                self.node(StructureKind::CheckAst, token_span, [], || CheckExpr {
                    kind: CheckExprKind::Int(value),
                    span: token_span,
                })
            }
            TokenKind::Float(value) => {
                let value = *value;
                self.bump();
                self.node(StructureKind::CheckAst, token_span, [], || CheckExpr {
                    kind: CheckExprKind::Float(value),
                    span: token_span,
                })
            }
            TokenKind::True => {
                self.bump();
                self.node(StructureKind::CheckAst, token_span, [], || CheckExpr {
                    kind: CheckExprKind::Bool(true),
                    span: token_span,
                })
            }
            TokenKind::False => {
                self.bump();
                self.node(StructureKind::CheckAst, token_span, [], || CheckExpr {
                    kind: CheckExprKind::Bool(false),
                    span: token_span,
                })
            }
            TokenKind::String(value) => {
                let value = std::mem::take(value);
                self.bump();
                self.node(StructureKind::CheckAst, token_span, [], || CheckExpr {
                    kind: CheckExprKind::String(value),
                    span: token_span,
                })
            }
            TokenKind::FormattedStringStart => self.parse_formatted_string(),
            TokenKind::Ident(value) => {
                let value = std::mem::take(value);
                self.bump();
                let first = NameRef {
                    name: value,
                    span: token_span,
                };
                let mut segments = vec![first];
                let mut end = token_span.end;
                while self.eat(&TokenKind::DoubleColon).is_some() {
                    let segment = self.expect_ident()?;
                    end = segment.span.end;
                    segments.push(segment);
                }
                let span = Span::new(token_span.start, end);
                if segments.len() > 2 {
                    return self.err_at(
                        CftErrorCode::InvalidCheckStatement,
                        span,
                        "static path must use `Enum::Variant`",
                    );
                }
                self.node(StructureKind::CheckAst, span, [], || CheckExpr {
                    kind: if segments.len() == 1 {
                        CheckExprKind::Name(segments.remove(0).name)
                    } else {
                        CheckExprKind::StaticPath(crate::syntax::ast::NamePath { segments, span })
                    },
                    span,
                })
            }
            TokenKind::LParen => {
                let opener = self.expect_simple(&TokenKind::LParen, CftErrorCode::ExpectedToken)?;
                let (mut expr, end) = self.nested(StructureKind::CheckAst, opener, |parser| {
                    let expr = parser.parse_or_expr()?;
                    let end = parser
                        .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                        .end;
                    Ok((expr, end))
                })?;
                expr.value.span = Span::new(opener.start, end);
                Ok(expr)
            }
            TokenKind::UIntOverflow(_) => self.err(
                CftErrorCode::InvalidIntLiteral,
                "integer literal out of range",
            ),
            _ => self.err(
                CftErrorCode::InvalidCheckStatement,
                "expected check expression",
            ),
        }
    }

    pub(super) fn parse_formatted_string(&mut self) -> Result<Parsed<CheckExpr>, CftDiagnostics> {
        let start = self
            .expect_simple(
                &TokenKind::FormattedStringStart,
                CftErrorCode::ExpectedToken,
            )?
            .start;
        let mut segments = Vec::new();
        let mut depths = Vec::new();
        while !self.at(&TokenKind::FormattedStringEnd) {
            let token_span = self.peek().span;
            match &mut self.tokens[self.pos].kind {
                TokenKind::FormattedStringText(value) => {
                    let value = std::mem::take(value);
                    self.bump();
                    segments.push(CheckFormatSegment::Text(value, token_span));
                }
                TokenKind::FormattedStringExprStart => {
                    let opener = self.bump();
                    let expr = self.nested(StructureKind::CheckAst, opener, |parser| {
                        parser.parse_or_expr()
                    })?;
                    // 消息插值只读取路径，不能借由检查表达式引入计算或调用。
                    if !is_interpolation_path(&expr.value) {
                        return self.err(
                            CftErrorCode::InvalidCheckStatement,
                            "formatted string interpolation requires a field path",
                        );
                    }
                    self.expect_simple(
                        &TokenKind::FormattedStringExprEnd,
                        CftErrorCode::ExpectedToken,
                    )?;
                    depths.push(expr.depth);
                    segments.push(CheckFormatSegment::Expr(expr.value));
                }
                TokenKind::Eof => {
                    return self.err(CftErrorCode::UnexpectedEof, "unterminated formatted string");
                }
                _ => {
                    return self.err(
                        CftErrorCode::InvalidCheckStatement,
                        "invalid formatted string segment",
                    );
                }
            }
        }
        let end = self
            .expect_simple(&TokenKind::FormattedStringEnd, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        self.node(StructureKind::CheckAst, span, depths, || CheckExpr {
            kind: CheckExprKind::FormattedString(segments),
            span,
        })
    }

    pub(super) fn parse_type_predicate(&mut self) -> Result<TypePredicate, CftDiagnostics> {
        let name = self.expect_ident_with_code(CftErrorCode::ExpectedIdentifier)?;
        if name.name == "Some" {
            self.expect_simple(&TokenKind::LParen, CftErrorCode::ExpectedToken)?;
            let binding = self.expect_ident()?;
            let end = self
                .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                .end;
            Ok(TypePredicate::Some {
                binding,
                span: Span::new(name.span.start, end),
            })
        } else {
            Ok(TypePredicate::Type(name))
        }
    }
}

fn is_interpolation_path(expr: &CheckExpr) -> bool {
    match &expr.kind {
        CheckExprKind::Name(_) | CheckExprKind::StaticPath(_) => true,
        CheckExprKind::Field { expr, .. } => is_interpolation_path(expr),
        _ => false,
    }
}
