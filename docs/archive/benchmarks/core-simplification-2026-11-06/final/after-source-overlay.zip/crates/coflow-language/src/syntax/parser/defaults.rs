use super::{negate_u64_to_i64, Parsed, Parser};
use crate::diagnostics::{CftDiagnostics, CftErrorCode};
use crate::limits::StructureKind;
use crate::source::Span;
use crate::syntax::ast::{DefaultExpr, DefaultExprKind};
use crate::syntax::lexer::TokenKind;

impl Parser<'_> {
    pub(super) fn parse_default_expr(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        self.parse_default_bit_or()
    }

    fn parse_default_bit_or(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let mut lhs = self.parse_default_bit_xor()?;
        while self.eat(&TokenKind::Pipe).is_some() {
            let rhs = self.parse_default_bit_xor()?;
            lhs = self.combine_default_bit_expr(crate::syntax::ast::DefaultBitOp::Or, lhs, rhs)?;
        }
        Ok(lhs)
    }

    fn parse_default_bit_xor(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let mut lhs = self.parse_default_bit_and()?;
        while self.eat(&TokenKind::Caret).is_some() {
            let rhs = self.parse_default_bit_and()?;
            lhs = self.combine_default_bit_expr(crate::syntax::ast::DefaultBitOp::Xor, lhs, rhs)?;
        }
        Ok(lhs)
    }

    fn parse_default_bit_and(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let mut lhs = self.parse_default_primary()?;
        while self.eat(&TokenKind::Amp).is_some() {
            let rhs = self.parse_default_primary()?;
            lhs = self.combine_default_bit_expr(crate::syntax::ast::DefaultBitOp::And, lhs, rhs)?;
        }
        Ok(lhs)
    }

    fn combine_default_bit_expr(
        &mut self,
        op: crate::syntax::ast::DefaultBitOp,
        lhs: Parsed<DefaultExpr>,
        rhs: Parsed<DefaultExpr>,
    ) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let span = Span::new(lhs.value.span.start, rhs.value.span.end);
        self.node(
            StructureKind::DefaultValue,
            span,
            [lhs.depth, rhs.depth],
            || DefaultExpr {
                kind: DefaultExprKind::BitExpr {
                    op,
                    lhs: Box::new(lhs.value),
                    rhs: Box::new(rhs.value),
                },
                span,
            },
        )
    }

    fn parse_default_primary(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let token_span = self.peek().span;
        match &mut self.tokens[self.pos].kind {
            TokenKind::Int(value) => {
                let value = *value;
                self.bump();
                self.node(StructureKind::DefaultValue, token_span, [], || {
                    DefaultExpr {
                        kind: DefaultExprKind::Int(value),
                        span: token_span,
                    }
                })
            }
            TokenKind::Float(value) => {
                let value = *value;
                self.bump();
                self.node(StructureKind::DefaultValue, token_span, [], || {
                    DefaultExpr {
                        kind: DefaultExprKind::Float(value),
                        span: token_span,
                    }
                })
            }
            TokenKind::True => {
                self.bump();
                self.node(StructureKind::DefaultValue, token_span, [], || {
                    DefaultExpr {
                        kind: DefaultExprKind::Bool(true),
                        span: token_span,
                    }
                })
            }
            TokenKind::False => {
                self.bump();
                self.node(StructureKind::DefaultValue, token_span, [], || {
                    DefaultExpr {
                        kind: DefaultExprKind::Bool(false),
                        span: token_span,
                    }
                })
            }
            TokenKind::String(value) => {
                let value = std::mem::take(value);
                self.bump();
                self.node(StructureKind::DefaultValue, token_span, [], || {
                    DefaultExpr {
                        kind: DefaultExprKind::String(value),
                        span: token_span,
                    }
                })
            }
            TokenKind::FormattedStringStart => self.parse_formatted_string_default(),
            TokenKind::Ident(_) => self.parse_name_or_enum_default(),
            TokenKind::LBracket => self.parse_array_default(),
            TokenKind::LBrace => self.parse_braced_default(),
            TokenKind::Amp => self.parse_record_reference_default(),
            TokenKind::Minus => self.parse_negative_default(token_span.start),
            TokenKind::LParen => {
                let opener = self.expect_simple(&TokenKind::LParen, CftErrorCode::ExpectedToken)?;
                let mut value = self.nested(StructureKind::DefaultValue, opener, |parser| {
                    parser.parse_default_expr()
                })?;
                let end = self
                    .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                    .end;
                value.value.span = Span::new(opener.start, end);
                Ok(value)
            }
            TokenKind::UIntOverflow(_) => self.err(
                CftErrorCode::InvalidIntLiteral,
                "integer literal out of range",
            ),
            _ => self.err(
                CftErrorCode::InvalidDefaultExpression,
                "expected default expression",
            ),
        }
    }

    fn parse_formatted_string_default(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let start = self
            .expect_simple(
                &TokenKind::FormattedStringStart,
                CftErrorCode::ExpectedToken,
            )?
            .start;
        while !self.at(&TokenKind::FormattedStringEnd) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated formatted string");
            }
            self.bump();
        }
        let end = self
            .expect_simple(&TokenKind::FormattedStringEnd, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        // 默认值与 CFD 共用基础插值语法，避免表达式和调用进入数据加载路径。
        let value = match crate::cfd::parse_value_span(self.source, span) {
            Ok(crate::cfd::CfdValue::FormattedString(value)) => value,
            Ok(_) => return self.err_at(
                CftErrorCode::InvalidDefaultExpression,
                span,
                "expected a formatted string default",
            ),
            Err(error) => return self.err_at(
                CftErrorCode::InvalidDefaultExpression,
                error.span,
                error.message,
            ),
        };
        self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
            kind: DefaultExprKind::FormattedString(std::sync::Arc::new(value)),
            span,
        })
    }

    fn parse_record_reference_default(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let start = self
            .expect_simple(&TokenKind::Amp, CftErrorCode::ExpectedToken)?
            .start;
        let path = self.expect_name_path()?;
        if path.segments.len() != 2 {
            return self.err_at(
                CftErrorCode::InvalidDefaultExpression,
                path.span,
                "record reference must use `Type::key`",
            );
        }
        let span = Span::new(start, path.span.end);
        self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
            kind: DefaultExprKind::RecordReference(path),
            span,
        })
    }

    fn parse_negative_default(
        &mut self,
        start: usize,
    ) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        self.bump();
        let span = Span::new(start, self.peek().span.end);
        match self.peek().kind {
            TokenKind::Int(value) => {
                self.bump();
                let Some(negated) = value.checked_neg() else {
                    return self.err_at(
                        CftErrorCode::InvalidIntLiteral,
                        span,
                        "negated integer literal overflowed",
                    );
                };
                self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
                    kind: DefaultExprKind::Int(negated),
                    span,
                })
            }
            TokenKind::UIntOverflow(value) => {
                self.bump();
                let Some(negated) = negate_u64_to_i64(value) else {
                    return self.err_at(
                        CftErrorCode::InvalidIntLiteral,
                        span,
                        "integer literal out of range",
                    );
                };
                self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
                    kind: DefaultExprKind::Int(negated),
                    span,
                })
            }
            TokenKind::Float(value) => {
                self.bump();
                self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
                    kind: DefaultExprKind::Float(-value),
                    span,
                })
            }
            _ => self.err(
                CftErrorCode::InvalidDefaultExpression,
                "expected number after `-`",
            ),
        }
    }

    fn parse_name_or_enum_default(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let first = self.expect_ident()?;
        if first.name == "None" {
            return self.node(StructureKind::DefaultValue, first.span, [], || {
                DefaultExpr {
                    span: first.span,
                    kind: DefaultExprKind::OptionNone,
                }
            });
        }
        if first.name == "Some" {
            self.expect_simple(&TokenKind::LParen, CftErrorCode::ExpectedToken)?;
            let inner_span = self.peek().span;
            let inner = self.nested(StructureKind::DefaultValue, inner_span, |parser| {
                parser.parse_default_expr()
            })?;
            let end = self
                .expect_simple(&TokenKind::RParen, CftErrorCode::ExpectedToken)?
                .end;
            let span = Span::new(first.span.start, end);
            let depth = inner.depth;
            let kind = DefaultExprKind::OptionSome(Box::new(inner.value));
            return self.node(StructureKind::DefaultValue, first.span, [depth], || {
                DefaultExpr { kind, span }
            });
        }
        let start = first.span.start;
        let mut end = first.span.end;
        let mut segments = vec![first];
        while self.eat(&TokenKind::DoubleColon).is_some() {
            let segment = self.expect_ident()?;
            end = segment.span.end;
            segments.push(segment);
        }
        let span = Span::new(start, end);
        let path = crate::syntax::ast::NamePath { segments, span };
        if self.at(&TokenKind::LBrace) {
            if path.segments.len() != 1 {
                return self.err_at(
                    CftErrorCode::InvalidDefaultExpression,
                    path.span,
                    "object default type must be a single identifier",
                );
            }
            return self.parse_typed_object_default(path);
        }
        if path.segments.len() > 2 {
            return self.err_at(
                CftErrorCode::InvalidDefaultExpression,
                path.span,
                "static path must use `Enum::Variant`",
            );
        }
        self.node(StructureKind::DefaultValue, span, [], || DefaultExpr {
            span,
            kind: DefaultExprKind::StaticPath(path),
        })
    }

    fn parse_typed_object_default(
        &mut self,
        type_name: crate::syntax::ast::NamePath,
    ) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let start = type_name.span.start;
        let opener = self.expect_simple(&TokenKind::LBrace, CftErrorCode::ExpectedToken)?;
        let mut fields = Vec::new();
        while !self.at(&TokenKind::RBrace) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated object default");
            }
            let name = self.expect_ident()?;
            self.expect_simple(&TokenKind::Colon, CftErrorCode::ExpectedToken)?;
            let value_span = self.peek().span;
            let value = self.nested(StructureKind::DefaultValue, value_span, |parser| {
                parser.parse_default_expr()
            })?;
            fields.push((name, value));
            if self.eat(&TokenKind::Comma).is_none() {
                break;
            }
        }
        let end = self
            .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        let depths = fields
            .iter()
            .map(|(_, value)| value.depth)
            .collect::<Vec<_>>();
        self.node(StructureKind::DefaultValue, opener, depths, || {
            DefaultExpr {
                kind: DefaultExprKind::TypedObject {
                    type_name,
                    fields: fields
                        .into_iter()
                        .map(|(name, value)| (name, value.value))
                        .collect(),
                },
                span,
            }
        })
    }

    fn parse_array_default(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let opener = self.expect_simple(&TokenKind::LBracket, CftErrorCode::ExpectedToken)?;
        let start = opener.start;
        let mut items = Vec::new();
        while !self.at(&TokenKind::RBracket) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated array default");
            }
            let child_span = self.peek().span;
            items.push(
                self.nested(StructureKind::DefaultValue, child_span, |parser| {
                    parser.parse_default_expr()
                })?,
            );
            if self.eat(&TokenKind::Comma).is_none() {
                break;
            }
        }
        let end = self
            .expect_simple(&TokenKind::RBracket, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        let depths = items.iter().map(|item| item.depth).collect::<Vec<_>>();
        self.node(StructureKind::DefaultValue, opener, depths, || {
            DefaultExpr {
                kind: DefaultExprKind::Array(items.into_iter().map(|item| item.value).collect()),
                span,
            }
        })
    }

    fn parse_braced_default(&mut self) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let opener = self.expect_simple(&TokenKind::LBrace, CftErrorCode::ExpectedToken)?;
        let start = opener.start;
        if self.at(&TokenKind::RBrace) {
            let end = self.bump().end;
            let span = Span::new(start, end);
            return self.node(StructureKind::DefaultValue, opener, [], || DefaultExpr {
                kind: DefaultExprKind::Object(Vec::new()),
                span,
            });
        }
        if !matches!(self.peek().kind, TokenKind::Ident(_)) || self.next_at(&TokenKind::DoubleColon)
        {
            return self.parse_dictionary_default_after_opener(opener);
        }
        let mut fields = Vec::new();
        while !self.at(&TokenKind::RBrace) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated object default");
            }
            let name = self.expect_ident()?;
            self.expect_simple(&TokenKind::Colon, CftErrorCode::ExpectedToken)?;
            let value_span = self.peek().span;
            let value = self.nested(StructureKind::DefaultValue, value_span, |parser| {
                parser.parse_default_expr()
            })?;
            fields.push((name, value));
            if self.eat(&TokenKind::Comma).is_none() {
                break;
            }
        }
        let end = self
            .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        let depths = fields
            .iter()
            .map(|(_, value)| value.depth)
            .collect::<Vec<_>>();
        self.node(StructureKind::DefaultValue, opener, depths, || {
            DefaultExpr {
                kind: DefaultExprKind::Object(
                    fields
                        .into_iter()
                        .map(|(name, value)| (name, value.value))
                        .collect(),
                ),
                span,
            }
        })
    }

    fn parse_dictionary_default_after_opener(
        &mut self,
        opener: Span,
    ) -> Result<Parsed<DefaultExpr>, CftDiagnostics> {
        let start = opener.start;
        let mut entries = Vec::new();
        while !self.at(&TokenKind::RBrace) {
            if self.at(&TokenKind::Eof) {
                return self.err(
                    CftErrorCode::UnexpectedEof,
                    "unterminated dictionary default",
                );
            }
            let key_span = self.peek().span;
            let key = self.nested(StructureKind::DefaultValue, key_span, |parser| {
                parser.parse_default_expr()
            })?;
            self.expect_simple(&TokenKind::Colon, CftErrorCode::ExpectedToken)?;
            let value_span = self.peek().span;
            let value = self.nested(StructureKind::DefaultValue, value_span, |parser| {
                parser.parse_default_expr()
            })?;
            entries.push((key, value));
            if self.eat(&TokenKind::Comma).is_none() {
                break;
            }
        }
        let end = self
            .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
            .end;
        let span = Span::new(start, end);
        let depths = entries
            .iter()
            .flat_map(|(key, value)| [key.depth, value.depth])
            .collect::<Vec<_>>();
        self.node(StructureKind::DefaultValue, opener, depths, || {
            DefaultExpr {
                kind: DefaultExprKind::Dictionary(
                    entries
                        .into_iter()
                        .map(|(key, value)| (key.value, value.value))
                        .collect(),
                ),
                span,
            }
        })
    }
}
