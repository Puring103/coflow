use super::annotations::{field_dimension_name, find_annotation, has_annotation};
use super::inferred_type::InferredType;
use super::ValidatedSchema;
use crate::schema::{
    CftAnnotation, CftAnnotationValue, CftConst, CftConstValue, CftDisplayMetadata, CftEnum,
    CftEnumVariant, CftField, CftFieldDimension, CftSchemaCheckBlock, CftSchemaCheckExpr,
    CftSchemaCheckExprKind, CftSchemaCheckFormatSegment, CftSchemaCheckMessage,
    CftSchemaCheckMessageKind, CftSchemaCheckStmt, CftSchemaDefaultValue, CftSchemaTypePredicate,
    CftTopLevelCheck, CftType,
};
use crate::syntax::ast::{
    Annotation, AnnotationArg, CheckExpr, CheckExprKind, CheckFormatSegment, CheckMessageKind,
    CheckStmt, DefaultExpr, FieldDef, TypePredicate,
};
use crate::{CheckName, ConstName, EnumName, EnumVariantName, FieldName, TypeName};
use std::collections::BTreeMap;
use std::sync::Arc;

impl ValidatedSchema<'_> {
    pub(super) fn lower_declarations(&self) -> super::SchemaDeclarations {
        super::SchemaDeclarations {
            consts: self.build_consts(),
            enums: self.build_enums(),
            types: self.build_types(),
            checks: self.build_checks(),
            sources: self
                .modules
                .modules()
                .map(|(id, module)| {
                    (
                        id.clone(),
                        crate::schema::CftSchemaSource {
                            path: module.path().to_path_buf(),
                            source: module.shared_source(),
                        },
                    )
                })
                .collect(),
        }
    }

    fn build_checks(&self) -> BTreeMap<CheckName, CftTopLevelCheck> {
        self.checks
            .iter()
            .map(|(name, info)| {
                let name = CheckName::from_validated(name.clone());
                let block = self.convert_check_block(&info.module, &info.def.block);
                let check = CftTopLevelCheck {
                    module: info.module.clone(),
                    name: name.clone(),
                    block,
                    span: info.def.span,
                };
                (name, check)
            })
            .collect()
    }

    fn build_consts(&self) -> BTreeMap<ConstName, CftConst> {
        let mut consts = BTreeMap::new();
        for (name, info) in &self.consts {
            let Some((value_type, value)) = self.constants.get(name) else {
                debug_assert!(false, "constants are resolved before lowering");
                continue;
            };
            let name = ConstName::from_validated(name.clone());
            let schema = CftConst {
                module: info.module.clone(),
                name: name.clone(),
                value_type: value_type.clone(),
                value: value.clone(),
                span: info.def.span,
            };
            consts.insert(name, schema);
        }
        consts
    }

    fn build_enums(&self) -> BTreeMap<EnumName, CftEnum> {
        let mut enums = BTreeMap::new();
        for (name, info) in &self.enums {
            // `validate_enums` already resolved every variant's integer value
            // (auto-numbered or explicit) into `values_by_name`. We just look
            // them up here instead of re-walking the sequence.
            let mut variants = info
                .def
                .variants
                .iter()
                .map(|variant| CftEnumVariant {
                    name: EnumVariantName::from_validated(variant.name.clone()),
                    value: info.values_by_name.get(&variant.name).copied().unwrap_or(0),
                    annotations: Self::schema_annotations(&variant.annotations),
                    display: display_metadata(&variant.annotations),
                    span: variant.span,
                })
                .collect::<Vec<_>>();
            if info.is_flag {
                for member in ["None", "Everything"] {
                    variants.push(CftEnumVariant {
                        name: EnumVariantName::from_validated(member),
                        value: info.values_by_name[member],
                        annotations: Vec::new(),
                        display: None,
                        span: info.def.span,
                    });
                }
            }
            let variant_by_name = variants
                .iter()
                .enumerate()
                .map(|(index, variant)| (variant.name.clone(), index))
                .collect();
            // 合成组合成员可以与单个标志同值，数值反查优先保留原始成员。
            let mut variant_by_value = BTreeMap::new();
            for (index, variant) in variants.iter().enumerate() {
                variant_by_value.entry(variant.value).or_insert(index);
            }
            let name = EnumName::from_validated(name.clone());
            let schema = CftEnum {
                module: info.module.clone(),
                name: name.clone(),
                variants,
                variant_by_name,
                variant_by_value,
                is_flag: has_annotation(&info.def.annotations, "flag"),
                is_int64: has_annotation(&info.def.annotations, "int64"),
                annotations: Self::schema_annotations(&info.def.annotations),
                display: display_metadata(&info.def.annotations),
                span: info.def.span,
            };
            enums.insert(name, schema);
        }
        enums
    }

    fn build_types(&self) -> BTreeMap<TypeName, CftType> {
        let own_fields = self
            .types
            .iter()
            .map(|(name, info)| {
                let type_name = TypeName::from_validated(name.clone());
                let fields = info
                    .def
                    .fields
                    .iter()
                    .zip(self.declared_field_types(info))
                    .map(|(field, declared_type)| {
                        Arc::new(self.build_schema_field(
                            &info.module,
                            field,
                            &type_name,
                            declared_type,
                        ))
                    })
                    .collect::<Vec<_>>();
                (type_name, fields)
            })
            .collect::<BTreeMap<_, _>>();
        let mut types = BTreeMap::new();
        for (name, info) in &self.types {
            let type_name = TypeName::from_validated(name.clone());
            let fields = own_fields.get(&type_name).cloned().unwrap_or_default();
            let all_fields = self.collect_all_schema_fields(name, &own_fields);
            let field_by_name = all_fields
                .iter()
                .enumerate()
                .map(|(index, field)| (field.name.clone(), index))
                .collect();
            let id_as_enum = find_annotation(&info.def.annotations, "idAsEnum")
                .and_then(|annotation| annotation.args.first())
                .and_then(|arg| match arg {
                    AnnotationArg::Name(name) => Some(EnumName::from_validated(name.name.clone())),
                    _ => None,
                });
            let schema = CftType {
                module: info.module.clone(),
                name: type_name.clone(),
                parent: info
                    .def
                    .parent
                    .as_ref()
                    .map(|parent| TypeName::from_validated(parent.name.clone())),
                is_abstract: info.def.is_abstract,
                is_sealed: info.def.is_sealed
                    || matches!(info.def.kind, crate::syntax::ast::TypeKind::Singleton),
                is_struct: has_annotation(&info.def.annotations, "struct"),
                kind: info.def.kind,
                id_as_enum,
                annotations: Self::schema_annotations(&info.def.annotations),
                display: display_metadata(&info.def.annotations),
                own_fields: fields,
                all_fields,
                field_by_name,
                checks: info
                    .def
                    .checks
                    .iter()
                    .map(|check| self.convert_check_block(&info.module, check))
                    .collect(),
                span: info.def.span,
            };
            types.insert(type_name, schema);
        }
        types
    }

    // 进入 lowering 前已经完成字段类型校验，未解析类型属于编译流水线不变量错误。
    #[allow(clippy::expect_used)]
    fn build_schema_field(
        &self,
        module: &crate::ModuleId,
        field: &FieldDef,
        owner_type: &TypeName,
        declared_type: &InferredType,
    ) -> CftField {
        let dimension =
            field_dimension_name(field).map(|dimension| CftFieldDimension { dimension });
        CftField {
            declaring_type: owner_type.clone(),
            name: FieldName::from_validated(field.name.clone()),
            value_type: declared_type
                .value_type()
                .cloned()
                .expect("validated field types must resolve before lowering"),
            default: field
                .default
                .as_ref()
                .and_then(|default| self.schema_default_value(module, default)),
            is_expand: has_annotation(&field.annotations, "expand"),
            dimension,
            annotations: Self::schema_annotations(&field.annotations),
            display: display_metadata(&field.annotations),
            span: field.span,
        }
    }

    fn schema_annotations(annotations: &[Annotation]) -> Vec<CftAnnotation> {
        annotations
            .iter()
            .map(|annotation| CftAnnotation {
                name: annotation.name.clone(),
                arguments: annotation
                    .args
                    .iter()
                    .map(|argument| match argument {
                        AnnotationArg::Name(name) => CftAnnotationValue::Name(name.name.clone()),
                        AnnotationArg::String(value, _) => {
                            CftAnnotationValue::String(value.clone())
                        }
                        AnnotationArg::Int(value, _) => CftAnnotationValue::Int(*value),
                        AnnotationArg::Float(value, _) => CftAnnotationValue::Float(*value),
                        AnnotationArg::Bool(value, _) => CftAnnotationValue::Bool(*value),
                    })
                    .collect(),
            })
            .collect()
    }

    fn collect_all_schema_fields(
        &self,
        type_name: &str,
        own_fields: &BTreeMap<TypeName, Vec<Arc<CftField>>>,
    ) -> Vec<Arc<CftField>> {
        self.ancestry_chain(type_name)
            .into_iter()
            .flat_map(|info| {
                own_fields
                    .get(info.name.as_str())
                    .cloned()
                    .unwrap_or_default()
            })
            .collect()
    }

    fn schema_default_value(
        &self,
        module: &crate::ModuleId,
        expr: &DefaultExpr,
    ) -> Option<CftSchemaDefaultValue> {
        let value = self
            .defaults
            .get(&(module.clone(), expr.span.start, expr.span.end))?;
        Some(const_value_as_default(value))
    }
}

fn const_value_as_default(value: &CftConstValue) -> CftSchemaDefaultValue {
    match value {
        CftConstValue::Int(value) | CftConstValue::Long(value) => {
            CftSchemaDefaultValue::Int(*value)
        }
        CftConstValue::Float(value) | CftConstValue::Double(value) => {
            CftSchemaDefaultValue::Float(*value)
        }
        CftConstValue::Bool(value) => CftSchemaDefaultValue::Bool(*value),
        CftConstValue::String(value) => CftSchemaDefaultValue::String(value.clone()),
        CftConstValue::FormattedString(source) => {
            CftSchemaDefaultValue::FormattedString(source.clone())
        }

        CftConstValue::Enum {
            enum_name,
            variant,
            value,
        } => CftSchemaDefaultValue::Enum {
            enum_name: enum_name.clone(),
            variant: variant.clone(),
            value: *value,
        },
        CftConstValue::OptionNone => CftSchemaDefaultValue::OptionNone,
        CftConstValue::OptionSome(value) => {
            CftSchemaDefaultValue::OptionSome(Box::new(const_value_as_default(value)))
        }
        CftConstValue::Array(values) => {
            CftSchemaDefaultValue::Array(values.iter().map(const_value_as_default).collect())
        }
        CftConstValue::Dictionary(entries) => CftSchemaDefaultValue::Dictionary(
            entries
                .iter()
                .map(|(key, value)| (const_value_as_default(key), const_value_as_default(value)))
                .collect(),
        ),
        CftConstValue::Object { fields, .. } if fields.is_empty() => {
            CftSchemaDefaultValue::EmptyObject
        }
        CftConstValue::Object { type_name, fields } => CftSchemaDefaultValue::Object {
            type_name: type_name.clone(),
            fields: fields
                .iter()
                .map(|(name, value)| (name.clone(), const_value_as_default(value)))
                .collect(),
        },
        CftConstValue::RecordReference { type_name, id: key } => {
            CftSchemaDefaultValue::RecordReference {
                type_name: type_name.clone(),
                id: key.clone(),
            }
        }
    }
}

impl ValidatedSchema<'_> {
    fn convert_check_block(
        &self,
        module: &crate::ModuleId,
        check: &crate::syntax::ast::CheckBlock,
    ) -> CftSchemaCheckBlock {
        CftSchemaCheckBlock {
            message: check
                .message
                .as_ref()
                .map(|message| self.convert_check_message(module, message)),
            name: check.name.clone().map_or_else(
                || CheckName::anonymous(module, check.span),
                CheckName::from_validated,
            ),
            name_span: check.name_span,
            stmts: check
                .stmts
                .iter()
                .map(|stmt| self.convert_check_stmt(module, stmt))
                .collect(),
            span: check.span,
            dimension_statements: self
                .check_dimensions
                .get(&(module.clone(), check.span.start, check.span.end))
                .cloned()
                .unwrap_or_default(),
            statement_dependencies: self
                .check_statement_dependencies
                .get(&(module.clone(), check.span.start, check.span.end))
                .cloned()
                .unwrap_or_else(|| {
                    vec![crate::schema::CheckStatementDependencies::default(); check.stmts.len()]
                }),
        }
    }

    fn convert_check_message(
        &self,
        module: &crate::ModuleId,
        message: &crate::syntax::ast::CheckMessage,
    ) -> CftSchemaCheckMessage {
        CftSchemaCheckMessage {
            kind: match &message.kind {
                CheckMessageKind::String(value) => CftSchemaCheckMessageKind::String(value.clone()),
                CheckMessageKind::Formatted(segments) => CftSchemaCheckMessageKind::Formatted(
                    self.convert_format_segments(module, segments),
                ),
            },
            span: message.span,
        }
    }

    fn convert_check_stmt(&self, module: &crate::ModuleId, stmt: &CheckStmt) -> CftSchemaCheckStmt {
        match stmt {
            CheckStmt::Expr {
                condition,
                message,
                span,
            } => CftSchemaCheckStmt::Expr {
                condition: self.convert_check_expr(module, condition),
                message: message
                    .as_ref()
                    .map(|message| self.convert_check_message(module, message)),
                span: *span,
            },
            CheckStmt::Quantifier {
                kind,
                bindings: _,
                collection,
                body,
                message,
                span,
            } => CftSchemaCheckStmt::Quantifier {
                kind: *kind,
                bindings: self.quantifier_bindings[&(module.clone(), span.start, span.end)].clone(),
                collection: self.convert_check_expr(module, collection),
                message: message
                    .as_ref()
                    .map(|message| self.convert_check_message(module, message)),
                body: body
                    .iter()
                    .map(|stmt| self.convert_check_stmt(module, stmt))
                    .collect(),
                span: *span,
            },
            CheckStmt::When {
                condition,
                body,
                message,
                span,
            } => CftSchemaCheckStmt::When {
                condition: self.convert_check_expr(module, condition),
                message: message
                    .as_ref()
                    .map(|message| self.convert_check_message(module, message)),
                body: body
                    .iter()
                    .map(|stmt| self.convert_check_stmt(module, stmt))
                    .collect(),
                span: *span,
            },
        }
    }
}

impl ValidatedSchema<'_> {
    // Check 表达式在此集中完成一对一 lowering，保持变体覆盖可审计。
    #[allow(clippy::too_many_lines)]
    fn convert_check_expr(&self, module: &crate::ModuleId, expr: &CheckExpr) -> CftSchemaCheckExpr {
        CftSchemaCheckExpr {
            kind: match &expr.kind {
                CheckExprKind::Int(value) => CftSchemaCheckExprKind::Int(*value),
                CheckExprKind::Float(value) => CftSchemaCheckExprKind::Float(*value),
                CheckExprKind::Bool(value) => CftSchemaCheckExprKind::Bool(*value),
                CheckExprKind::String(value) => CftSchemaCheckExprKind::String(value.clone()),
                CheckExprKind::FormattedString(segments) => {
                    CftSchemaCheckExprKind::FormattedString(
                        self.convert_format_segments(module, segments),
                    )
                }
                CheckExprKind::Name(name) => CftSchemaCheckExprKind::Name(name.clone()),
                CheckExprKind::StaticPath(path) => {
                    let raw_name = path.canonical();
                    let resolved_name = raw_name;
                    if self.consts.contains_key(&resolved_name)
                        || self.enums.contains_key(&resolved_name)
                    {
                        CftSchemaCheckExprKind::Name(resolved_name)
                    } else {
                        // 语法层保证名称路径至少包含一个段，这里直接拆出末段作为枚举成员。
                        let Some((variant, owner)) = path.segments.split_last() else {
                            debug_assert!(false, "name path must contain at least one segment");
                            return CftSchemaCheckExpr {
                                kind: CftSchemaCheckExprKind::Name(resolved_name),
                                span: expr.span,
                            };
                        };
                        let owner = owner
                            .iter()
                            .map(|segment| segment.name.as_str())
                            .collect::<Vec<_>>()
                            .join("::");
                        CftSchemaCheckExprKind::Field {
                            expr: Box::new(CftSchemaCheckExpr {
                                kind: CftSchemaCheckExprKind::Name(owner),
                                span: path.span,
                            }),
                            name: FieldName::from_validated(variant.name.clone()),
                        }
                    }
                }
                CheckExprKind::Records { type_name } => CftSchemaCheckExprKind::Records {
                    type_name: TypeName::from_validated(type_name.name.clone()),
                },
                CheckExprKind::Field { expr: inner, name } => CftSchemaCheckExprKind::Field {
                    expr: Box::new(self.convert_check_expr(module, inner)),
                    name: FieldName::from_validated(name.name.clone()),
                },
                CheckExprKind::Index { expr: inner, index } => CftSchemaCheckExprKind::Index {
                    expr: Box::new(self.convert_check_expr(module, inner)),
                    index: Box::new(self.convert_check_expr(module, index)),
                },
                CheckExprKind::Is {
                    expr: inner,
                    predicate,
                } => CftSchemaCheckExprKind::Is {
                    expr: Box::new(self.convert_check_expr(module, inner)),
                    predicate: match predicate {
                        TypePredicate::Some { binding, .. } => CftSchemaTypePredicate::Some {
                            binding: binding.name.clone(),
                        },
                        TypePredicate::Type(name) => {
                            CftSchemaTypePredicate::Type(TypeName::from_validated(
                                self.resolved_aliases
                                    .get(&name.name)
                                    .and_then(InferredType::object_name)
                                    .map_or_else(|| name.name.clone(), ToString::to_string),
                            ))
                        }
                    },
                },
                CheckExprKind::Call { name, args } => CftSchemaCheckExprKind::Call {
                    name: name.name.clone(),
                    args: args
                        .iter()
                        .map(|arg| self.convert_check_expr(module, arg))
                        .collect(),
                },
                CheckExprKind::MethodCall {
                    receiver,
                    name,
                    args,
                } => CftSchemaCheckExprKind::MethodCall {
                    receiver: Box::new(self.convert_check_expr(module, receiver)),
                    name: name.name.clone(),
                    args: args
                        .iter()
                        .map(|arg| self.convert_check_expr(module, arg))
                        .collect(),
                },
                CheckExprKind::BinOp { op, lhs, rhs } => CftSchemaCheckExprKind::BinOp {
                    op: *op,
                    lhs: Box::new(self.convert_check_expr(module, lhs)),
                    rhs: Box::new(self.convert_check_expr(module, rhs)),
                },
                CheckExprKind::Unary { op, expr: inner } => CftSchemaCheckExprKind::Unary {
                    op: *op,
                    expr: Box::new(self.convert_check_expr(module, inner)),
                },
                CheckExprKind::CmpChain { first, rest } => CftSchemaCheckExprKind::CmpChain {
                    first: Box::new(self.convert_check_expr(module, first)),
                    rest: rest
                        .iter()
                        .map(|(op, rhs)| (*op, self.convert_check_expr(module, rhs)))
                        .collect(),
                },
            },
            span: expr.span,
        }
    }

    fn convert_format_segments(
        &self,
        module: &crate::ModuleId,
        segments: &[CheckFormatSegment],
    ) -> Vec<CftSchemaCheckFormatSegment> {
        segments
            .iter()
            .map(|segment| match segment {
                CheckFormatSegment::Text(value, span) => {
                    CftSchemaCheckFormatSegment::Text(value.clone(), *span)
                }
                CheckFormatSegment::Expr(expr) => {
                    CftSchemaCheckFormatSegment::Expr(self.convert_check_expr(module, expr))
                }
            })
            .collect()
    }
}

fn display_metadata(annotations: &[Annotation]) -> Option<CftDisplayMetadata> {
    let string_arg = |name| {
        find_annotation(annotations, name)
            .and_then(|annotation| annotation.args.first())
            .and_then(|arg| match arg {
                AnnotationArg::String(value, _) => Some(value.clone()),
                _ => None,
            })
    };
    let label = string_arg("label");
    let description = string_arg("description");
    (label.is_some() || description.is_some()).then_some(CftDisplayMetadata { label, description })
}
