use super::{negate_u64_to_i64, Parser};
use crate::diagnostics::{CftDiagnostics, CftErrorCode};
use crate::syntax::ast::SignedInt;
use crate::syntax::lexer::TokenKind;

impl Parser<'_> {
    pub(super) fn parse_signed_int(&mut self) -> Result<SignedInt, CftDiagnostics> {
        let sign_span = self.eat(&TokenKind::Minus);
        let token_span = self.peek().span;
        let span = sign_span.map_or(token_span, |span| span.join(token_span));
        match self.peek().kind {
            TokenKind::Int(value) => {
                self.bump();
                let value = if sign_span.is_some() {
                    let Some(negated) = value.checked_neg() else {
                        return self.err_at(
                            CftErrorCode::InvalidIntLiteral,
                            span,
                            "negated integer literal overflowed",
                        );
                    };
                    negated
                } else {
                    value
                };
                Ok(SignedInt { value, span })
            }
            TokenKind::UIntOverflow(value) => {
                self.bump();
                if sign_span.is_some() {
                    let Some(negated) = negate_u64_to_i64(value) else {
                        return self.err_at(
                            CftErrorCode::InvalidIntLiteral,
                            span,
                            "integer literal out of range",
                        );
                    };
                    Ok(SignedInt {
                        value: negated,
                        span,
                    })
                } else {
                    self.err_at(
                        CftErrorCode::InvalidIntLiteral,
                        span,
                        "integer literal out of range",
                    )
                }
            }
            _ => self.err(CftErrorCode::ExpectedToken, "expected integer literal"),
        }
    }
}
