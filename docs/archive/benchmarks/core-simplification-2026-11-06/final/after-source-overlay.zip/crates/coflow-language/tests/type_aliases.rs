#![allow(clippy::expect_used, clippy::needless_raw_string_hashes)]

use coflow_language::cft::{
    build_schema, parse_modules, CftFile, CftValueType, EnumName, ModuleId,
};
use coflow_language::diagnostics::CftErrorCode;

fn compile(
    source: &str,
) -> Result<coflow_language::cft::CftSchema, coflow_language::diagnostics::CftDiagnostics> {
    let modules = parse_modules([CftFile::from_source(ModuleId::from("main.cft"), source)]);
    build_schema(&modules)
}

#[test]
fn aliases_expand_in_fields_constants_and_nested_collections() {
    let schema = compile(
        r#"
            enum Kind { First }
            type Key = Kind;
            type ScoreGroups = [Scores];
            type Scores = {Key: int};
            const EMPTY: Scores = {};

            table Rule {
                groups: ScoreGroups;
                scores: Scores = EMPTY;
            }
        "#,
    )
    .expect("aliases should expand to their value types");

    let rule = schema.resolve_type("Rule").expect("Rule");
    assert_eq!(
        rule.field("groups").expect("groups").value_type,
        CftValueType::Array(Box::new(CftValueType::Dict(
            Box::new(CftValueType::Enum(
                EnumName::new("Kind").expect("enum name")
            )),
            Box::new(CftValueType::Int),
        )))
    );
    assert_eq!(
        rule.field("scores").expect("scores").value_type,
        CftValueType::Dict(
            Box::new(CftValueType::Enum(
                EnumName::new("Kind").expect("enum name")
            )),
            Box::new(CftValueType::Int),
        )
    );
    assert!(schema.resolve_type("Scores").is_none());
    assert!(schema.resolve_type("ScoreGroups").is_none());
}

#[test]
fn aliases_resolve_by_project_global_short_name_across_files() {
    let modules = parse_modules([
        CftFile::from_source(
            ModuleId::from("shared.cft"),
            r#"
                type Identifier = string;
                type MaybeIdentifier = Option<Identifier>;
            "#,
        ),
        CftFile::from_source(
            ModuleId::from("main.cft"),
            r#"
                type LocalIdentifier = MaybeIdentifier;
                table Item { identifier: LocalIdentifier = None; }
            "#,
        ),
    ]);
    let schema = build_schema(&modules).expect("project-global aliases should resolve");
    assert_eq!(
        schema
            .resolve_type("Item")
            .expect("Item")
            .field("identifier")
            .expect("identifier")
            .value_type,
        CftValueType::Option(Box::new(CftValueType::String))
    );
}

#[test]
fn alias_cycles_are_rejected_with_a_dedicated_diagnostic() {
    let diagnostics = compile(
        r#"
            type A = Option<B>;
            type B = {int: C};
            type C = A;
            table Item { value: A; }
        "#,
    )
    .expect_err("alias cycles must be rejected");
    assert!(diagnostics
        .diagnostics
        .iter()
        .any(|diagnostic| diagnostic.code == CftErrorCode::TypeAliasCycle));
}

#[test]
fn aliases_reject_unknown_targets_invalid_dict_keys_and_inheritance() {
    let unknown = compile("type MissingAlias = Missing;")
        .expect_err("unknown alias targets must be rejected");
    assert!(unknown
        .diagnostics
        .iter()
        .any(|diagnostic| diagnostic.code == CftErrorCode::UnknownNamedType));

    let invalid_key = compile("type BadKey = [int]; type Values = {BadKey: string};")
        .expect_err("expanded dict keys must be validated");
    assert!(invalid_key
        .diagnostics
        .iter()
        .any(|diagnostic| diagnostic.code == CftErrorCode::InvalidDictKeyType));

    let parent = compile("table Base {} type Alias = &Base; table Child : Alias {}")
        .expect_err("aliases cannot stand in for inheritance declarations");
    assert!(parent
        .diagnostics
        .iter()
        .any(|diagnostic| diagnostic.code == CftErrorCode::ParentMustBeType));
}

#[test]
fn type_aliases_do_not_accept_annotations_or_object_modifiers() {
    let annotation = compile("@label(\"identifier\") type Identifier = string;")
        .expect_err("annotations do not target aliases");
    assert!(annotation
        .diagnostics
        .iter()
        .any(|diagnostic| diagnostic.code == CftErrorCode::InvalidAnnotationTarget));

    assert!(compile("sealed type Identifier = string;").is_err());
    assert!(compile("abstract type Identifier = string;").is_err());
}

#[test]
fn object_aliases_are_transparent_in_check_type_positions() {
    compile(
        r#"
            data Item { value: int; }
            type ItemAlias = Item;
            table Holder { target: Item; check Valid { target is ItemAlias; } }
        "#,
    )
    .expect("object aliases should work in is predicates");
    compile(
        r#"
            table Item { value: int; }
            type ItemAlias = &Item;
            check AllItems {
                all item in records(ItemAlias) { item.value >= 0; }
            }
        "#,
    )
    .expect("object aliases should work in records queries");
}

#[test]
fn inherited_alias_fields_keep_resolved_types_and_defaults() {
    let schema = compile(
        r#"
            type Scores = {string: Option<[long]>};
            abstract table Base { scores: Scores = {"ready": Some([3])}; }
            table Child: Base { check Valid { scores.len() > 0; } }
        "#,
    )
    .expect("inherited alias type and default should compile together");
    let parent = schema.resolve_type("Base").expect("Base");
    let child = schema.resolve_type("Child").expect("Child");
    let parent_field = parent.field("scores").expect("parent scores");
    let child_field = child.field("scores").expect("child scores");
    assert_eq!(parent_field, child_field);
    assert_eq!(
        child_field.value_type,
        CftValueType::Dict(
            Box::new(CftValueType::String),
            Box::new(CftValueType::Option(Box::new(CftValueType::Array(
                Box::new(CftValueType::Long)
            )))),
        )
    );
    assert!(child_field.default.is_some());
}
