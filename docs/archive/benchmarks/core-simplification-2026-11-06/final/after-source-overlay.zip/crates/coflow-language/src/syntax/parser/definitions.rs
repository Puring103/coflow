use super::{Parsed, Parser};
use crate::diagnostics::{CftDiagnostics, CftErrorCode};
use crate::limits::StructureKind;
use crate::source::Span;
use crate::syntax::ast::{
    Annotation, ConstDef, EnumDef, EnumVariant, FieldDef, Item, TypeAliasDef, TypeDef, TypeKind,
    TypeRef, TypeRefKind,
};
use crate::syntax::lexer::{Token, TokenKind};

impl Parser<'_> {
    pub(super) fn parse_const(
        &mut self,
        annotations: Vec<Annotation>,
    ) -> Result<ConstDef, CftDiagnostics> {
        let start = self
            .expect_simple(&TokenKind::Const, CftErrorCode::UnexpectedToken)?
            .start;
        let name = self.expect_ident()?;
        let ty = if self.eat(&TokenKind::Colon).is_some() {
            Some(self.parse_value_type()?.value)
        } else {
            None
        };
        self.expect_simple(&TokenKind::Equal, CftErrorCode::ExpectedToken)?;
        let value = self.parse_default_expr()?.value;
        let end = self
            .expect_simple(&TokenKind::Semicolon, CftErrorCode::ExpectedToken)?
            .end;
        Ok(ConstDef {
            name: name.name,
            name_span: name.span,
            ty,
            value,
            annotations,
            span: Span::new(start, end),
        })
    }

    pub(super) fn parse_enum(
        &mut self,
        annotations: Vec<Annotation>,
    ) -> Result<EnumDef, CftDiagnostics> {
        let start = self
            .expect_simple(&TokenKind::Enum, CftErrorCode::UnexpectedToken)?
            .start;
        let name = self.expect_ident()?;
        self.expect_simple(&TokenKind::LBrace, CftErrorCode::ExpectedToken)?;
        let mut variants = Vec::new();
        let mut dangling_annotations = Vec::new();
        let mut pending_annotations = Vec::new();
        while !self.at(&TokenKind::RBrace) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated enum definition");
            }
            while self.at(&TokenKind::At) {
                pending_annotations.push(self.parse_annotation()?);
            }
            if self.at(&TokenKind::RBrace) {
                dangling_annotations.append(&mut pending_annotations);
                break;
            }
            let variant_start = self.peek().span.start;
            let variant = self.expect_ident()?;
            let value = if self.eat(&TokenKind::Equal).is_some() {
                Some(self.parse_signed_int()?)
            } else {
                None
            };
            let end = self.prev_span().end;
            variants.push(EnumVariant {
                name: variant.name,
                name_span: variant.span,
                value,
                annotations: std::mem::take(&mut pending_annotations),
                span: Span::new(variant_start, end),
            });
            self.charge_nodes(StructureKind::SyntaxAst, Span::new(variant_start, end), 1)?;
            if self.eat(&TokenKind::Comma).is_none() {
                break;
            }
        }
        let end = self
            .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
            .end;
        Ok(EnumDef {
            name: name.name,
            name_span: name.span,
            variants,
            annotations,
            dangling_annotations,
            span: Span::new(start, end),
        })
    }

    #[expect(
        clippy::too_many_lines,
        reason = "按语言或命令分支集中处理，保持分派与各分支语义可直接核对。"
    )]
    pub(super) fn parse_type(
        &mut self,
        annotations: Vec<Annotation>,
    ) -> Result<Item, CftDiagnostics> {
        let start = self.peek().span.start;
        let mut is_abstract = false;
        let mut abstract_span = None;
        let mut is_sealed = false;
        let mut sealed_span = None;
        loop {
            if let Some(span) = self.eat(&TokenKind::Abstract) {
                is_abstract = true;
                abstract_span = Some(span);
            } else if let Some(span) = self.eat(&TokenKind::Sealed) {
                is_sealed = true;
                sealed_span = Some(span);
            } else {
                break;
            }
        }
        let declaration_span = self.peek().span;
        let kind = match self.peek().kind {
            TokenKind::Table => Some(TypeKind::Table),
            TokenKind::Data => Some(TypeKind::Data),
            TokenKind::Singleton => Some(TypeKind::Singleton),
            TokenKind::Type => None,
            _ => {
                self.bump();
                return self.err_at(
                    CftErrorCode::ExpectedToken,
                    declaration_span,
                    "expected table, data, singleton, or type alias",
                )
            }
        };
        self.bump();
        let name = self.expect_ident()?;
        let Some(kind) = kind else {
            self.expect_simple(&TokenKind::Equal, CftErrorCode::ExpectedToken)?;
            if let Some(span) = abstract_span.or(sealed_span) {
                return self.err_at(
                    CftErrorCode::InvalidTopLevelItem,
                    span,
                    "type aliases cannot have abstract or sealed modifiers",
                );
            }
            let target = self.parse_value_type()?.value;
            let end = self
                .expect_simple(&TokenKind::Semicolon, CftErrorCode::ExpectedToken)?
                .end;
            return Ok(Item::TypeAlias(TypeAliasDef {
                name: name.name,
                name_span: name.span,
                target,
                annotations,
                span: Span::new(start, end),
            }));
        };
        let parent = if self.eat(&TokenKind::Colon).is_some() {
            Some(self.expect_ident_with_code(CftErrorCode::ExpectedIdentifier)?)
        } else {
            None
        };
        self.expect_simple(&TokenKind::LBrace, CftErrorCode::ExpectedToken)?;
        let mut fields = Vec::new();
        let mut checks = Vec::new();
        let mut dangling_annotations = Vec::new();
        let mut pending_annotations = Vec::new();
        let mut seen_check = false;
        while !self.at(&TokenKind::RBrace) {
            if self.at(&TokenKind::Eof) {
                return self.err(CftErrorCode::UnexpectedEof, "unterminated type definition");
            }
            while self.at(&TokenKind::At) {
                pending_annotations.push(self.parse_annotation()?);
            }
            if self.at(&TokenKind::RBrace) {
                dangling_annotations.append(&mut pending_annotations);
                break;
            }
            // check: 类型 是普通字段，check: 字符串 则是带消息的匿名规则。
            let check_message = self.tokens.get(self.pos + 2).is_some_and(|token| {
                matches!(
                    token.kind,
                    TokenKind::String(_) | TokenKind::FormattedStringStart
                )
            });
            if self.at(&TokenKind::Check) && (!self.next_at(&TokenKind::Colon) || check_message) {
                if !pending_annotations.is_empty() {
                    dangling_annotations.append(&mut pending_annotations);
                }
                seen_check = true;
                checks.push(self.parse_check_block()?);
                continue;
            }
            if seen_check {
                return self.err(
                    CftErrorCode::CheckBlockMustBeLast,
                    "check block must be the last item in a type",
                );
            }
            fields.push(self.parse_field(std::mem::take(&mut pending_annotations))?);
        }
        let end = self
            .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
            .end;
        Ok(Item::Type(TypeDef {
            kind,
            name: name.name,
            name_span: name.span,
            is_abstract,
            abstract_span,
            is_sealed,
            sealed_span,
            parent,
            fields,
            checks,
            annotations,
            dangling_annotations,
            span: Span::new(start, end),
        }))
    }

    fn parse_field(&mut self, annotations: Vec<Annotation>) -> Result<FieldDef, CftDiagnostics> {
        let start = self.peek().span.start;
        let name = self.expect_ident()?;
        self.expect_simple(&TokenKind::Colon, CftErrorCode::ExpectedToken)?;
        let ty = self.parse_value_type()?.value;
        let default = if self.eat(&TokenKind::Equal).is_some() {
            Some(self.parse_default_expr()?.value)
        } else {
            None
        };
        let end = self
            .expect_simple(&TokenKind::Semicolon, CftErrorCode::ExpectedToken)?
            .end;
        let field = FieldDef {
            name: name.name,
            name_span: name.span,
            ty,
            default,
            annotations,
            span: Span::new(start, end),
        };
        self.charge_nodes(StructureKind::SyntaxAst, field.span, 1)?;
        Ok(field)
    }

    pub(super) fn parse_value_type(&mut self) -> Result<Parsed<TypeRef>, CftDiagnostics> {
        self.parse_value_type_primary()
    }

    // 类型语法的所有首 token 分支集中处理，便于核对递归深度预算。
    #[allow(clippy::too_many_lines)]
    fn parse_value_type_primary(&mut self) -> Result<Parsed<TypeRef>, CftDiagnostics> {
        if self.peek_ident_is("Option") {
            let start = self.expect_ident()?.span;
            self.expect_simple(&TokenKind::Less, CftErrorCode::ExpectedToken)?;
            // Option 泛型与集合类型共享递归深度预算，解析内部类型前先进入。
            let inner = self.nested(StructureKind::TypeRef, start, |parser| {
                parser.parse_value_type()
            })?;
            let end = self.expect_type_close()?.end;
            let depth = inner.depth;
            return self.node(StructureKind::TypeRef, start, [depth], || TypeRef {
                span: Span::new(start.start, end),
                kind: TypeRefKind::Option(Box::new(inner.value)),
            });
        }
        // 引用类型保留显式 & 标记，与 CFD 引用值使用同一语法提示。
        if let Some(start) = self.eat(&TokenKind::Amp) {
            let inner = self.nested(StructureKind::TypeRef, start, |parser| {
                parser.parse_value_type_primary()
            })?;
            let span = Span::new(start.start, inner.value.span.end);
            let depth = inner.depth;
            return self.node(StructureKind::TypeRef, start, [depth], || TypeRef {
                span,
                kind: TypeRefKind::Ref(Box::new(inner.value)),
            });
        }
        if let Some(start) = self.eat(&TokenKind::LBracket) {
            let inner = self.nested(StructureKind::TypeRef, start, |parser| {
                parser.parse_value_type()
            })?;
            let end = self
                .expect_simple(&TokenKind::RBracket, CftErrorCode::ExpectedToken)?
                .end;
            let depth = inner.depth;
            self.node(StructureKind::TypeRef, start, [depth], || TypeRef {
                span: Span::new(start.start, end),
                kind: TypeRefKind::Array(Box::new(inner.value)),
            })
        } else if let Some(start) = self.eat(&TokenKind::LBrace) {
            let key = self.nested(StructureKind::TypeRef, start, |parser| {
                parser.parse_value_type()
            })?;
            self.expect_simple(&TokenKind::Colon, CftErrorCode::ExpectedToken)?;
            let value_span = self.peek().span;
            let value = self.nested(StructureKind::TypeRef, value_span, |parser| {
                parser.parse_value_type()
            })?;
            let end = self
                .expect_simple(&TokenKind::RBrace, CftErrorCode::ExpectedToken)?
                .end;
            let depths = [key.depth, value.depth];
            self.node(StructureKind::TypeRef, start, depths, || TypeRef {
                span: Span::new(start.start, end),
                kind: TypeRefKind::Dict(Box::new(key.value), Box::new(value.value)),
            })
        } else {
            let name = self.expect_ident_with_code(CftErrorCode::ExpectedIdentifier)?;
            let kind = match name.name.as_str() {
                "int" => TypeRefKind::Int,
                "long" => TypeRefKind::Long,
                "double" => TypeRefKind::Double,
                "float" => TypeRefKind::Float,
                "bool" => TypeRefKind::Bool,
                "string" => TypeRefKind::String,
                _ => TypeRefKind::Named(name.name),
            };
            self.node(StructureKind::TypeRef, name.span, [], || TypeRef {
                kind,
                span: name.span,
            })
        }
    }

    fn expect_type_close(&mut self) -> Result<Span, CftDiagnostics> {
        let span = self.peek().span;
        match self.peek().kind {
            TokenKind::Greater => Ok(self.bump()),
            TokenKind::GreaterGreater => {
                let split = span.start + 1;
                self.tokens[self.pos] = Token {
                    kind: TokenKind::Greater,
                    span: Span::new(split, span.end),
                };
                Ok(Span::new(span.start, split))
            }
            TokenKind::GreaterEq => {
                let split = span.start + 1;
                self.tokens[self.pos] = Token {
                    kind: TokenKind::Equal,
                    span: Span::new(split, span.end),
                };
                Ok(Span::new(span.start, split))
            }
            _ => self.err(CftErrorCode::ExpectedToken, "expected `>`"),
        }
    }
}
