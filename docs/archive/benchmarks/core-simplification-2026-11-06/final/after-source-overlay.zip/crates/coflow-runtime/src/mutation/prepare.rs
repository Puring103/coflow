use std::collections::{BTreeMap, BTreeSet};

use crate::api::DiagnosticSet;
use crate::api::WriteFieldPathSegment;
use crate::data_model::{CfdPath, CfdPathSegment, CfdValue, PendingInsertRef};
use coflow_language::cft::{CftValueType, RecordId};

use crate::write_rules;
use crate::writes::WriteTarget;
use crate::{ProjectSession, RecordCoordinate};

use super::coercion::{coerce_cfd_field_value, coerce_json_field_value, coerce_mutation_value};
use super::defaults::{
    create_record_draft_for_type, default_missing_fields_for_type, default_object_for_type,
    default_value_for_value_type,
};
use super::types::PreparedMutationOp;
use super::{one_mutation_error, one_path_error, schema_field, validated_record_coordinate};
use super::{CreateRecordDraft, DefaultMaterialization, MutationFields, MutationOp};

impl ProjectSession {
    /// Build a schema-shaped default record value.
    ///
    /// # Errors
    ///
    /// Returns diagnostics when `type_name` is not known in the compiled
    /// schema.
    pub fn default_record_value(
        &self,
        type_name: &str,
        materialization: DefaultMaterialization,
    ) -> Result<CfdValue, DiagnosticSet> {
        let object = default_object_for_type(self.schema(), type_name, materialization)?;
        Ok(CfdValue::Object(Box::new(object)))
    }

    /// Build a field-by-field draft for creating a new top-level record.
    ///
    /// The returned draft distinguishes schema defaults (shown in the editor
    /// but not persisted unless changed), type seeds (safe values that keep a
    /// new record loadable), and required inputs (values the host must collect
    /// from the user before calling insert).
    ///
    /// # Errors
    ///
    /// Returns diagnostics when `type_name` is unknown or cannot be inserted
    /// as a concrete top-level record draft.
    pub fn create_record_draft(&self, type_name: &str) -> Result<CreateRecordDraft, DiagnosticSet> {
        create_record_draft_for_type(self.schema(), type_name)
    }

    /// Build a default value for an item of the collection at `path`.
    ///
    /// # Errors
    ///
    /// Returns diagnostics when the path is not a collection field or when a
    /// default reference item cannot be chosen because no target record exists.
    pub fn default_collection_item_value(
        &self,
        actual_type: &str,
        path: &[CfdPathSegment],
    ) -> Result<CfdValue, DiagnosticSet> {
        let ty = write_rules::expected_type_for_cfd_path(
            self.schema(),
            actual_type,
            path,
            "MUTATION-PATH",
            "MUTATION",
        )?;
        self.default_collection_item_for_type(&ty)
    }

    /// Build a default collection item using concrete object types found in an
    /// existing record value while traversing the path.
    pub fn default_collection_item_value_for_record(
        &self,
        coordinate: &RecordCoordinate,
        path: &[CfdPathSegment],
    ) -> Result<CfdValue, DiagnosticSet> {
        let record = self
            .record_view(&coordinate.actual_type, &coordinate.id)
            .map(|view| view.record)
            .ok_or_else(|| one_path_error("record was not found"))?;
        let ty = write_rules::expected_type_for_record_path(
            self.schema(),
            record,
            path,
            "MUTATION-PATH",
            "MUTATION",
        )?;
        self.default_collection_item_for_type(&ty)
    }

    fn default_collection_item_for_type(
        &self,
        collection_type: &CftValueType,
    ) -> Result<CfdValue, DiagnosticSet> {
        let item_ty = match collection_type {
            CftValueType::Array(item) | CftValueType::Dict(_, item) => item.as_ref(),
            _ => {
                return Err(one_path_error(
                    "mutation path does not point to a collection",
                ));
            }
        };
        default_value_for_value_type(
            self.schema(),
            item_ty,
            DefaultMaterialization::EditableShape,
        )
    }
}

#[allow(clippy::too_many_lines)]
pub(super) fn prepare_one(
    session: &ProjectSession,
    op: MutationOp,
    pending_records: &BTreeMap<RecordCoordinate, usize>,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    match op {
        MutationOp::RestoreRecord { snapshot } => {
            ensure_type_can_insert(session, &snapshot.record.actual_type)?;
            ensure_record_id_available(
                session,
                &snapshot.record.actual_type,
                &snapshot.record.id,
                None,
                "MUTATION-INSERT",
                "MUTATION-INSERT-CONFLICT",
            )?;
            if snapshot.patches.is_empty() {
                return Err(one_mutation_error(
                    "MUTATION-INSERT",
                    "record restore snapshot is empty",
                ));
            }
            for patch in &snapshot.patches {
                ensure_source_file(session, &patch.file)?;
            }
            Ok(PreparedMutationOp::RestoreRecord { snapshot })
        }
        MutationOp::InsertRecord {
            file,
            actual_type,
            id,
            fields,
            materialization,
        } => {
            ensure_source_file(session, &file)?;
            ensure_type_can_insert(session, &actual_type)?;
            ensure_record_id_available(
                session,
                &actual_type,
                &id,
                None,
                "MUTATION-INSERT",
                "MUTATION-INSERT-CONFLICT",
            )?;
            let fields = prepare_insert_fields(
                session,
                &actual_type,
                &id,
                fields,
                materialization,
                pending_records,
            )?;
            let coordinate = validated_record_coordinate(actual_type, id)?;
            Ok(PreparedMutationOp::InsertRecord {
                file,
                actual_type: coordinate.actual_type,
                id: coordinate.id,
                fields,
            })
        }
        MutationOp::SetField {
            record,
            file,
            path,
            value,
        } if matches!(path.as_slice(), [CfdPathSegment::Field(field)] if field == "id") => {
            // id 是记录身份而非声明字段；沿用改名管线同步引用、维度来源与枚举编号。
            let CfdValue::String(new_id) =
                coerce_mutation_value(session, &CftValueType::String, value, pending_records)?
            else {
                return Err(one_mutation_error(
                    "MUTATION-RENAME",
                    "record ids must be strings",
                ));
            };
            prepare_one(
                session,
                MutationOp::RenameRecord {
                    record,
                    file,
                    new_id,
                },
                pending_records,
            )
        }
        MutationOp::SetField {
            record,
            file,
            path,
            value,
        } => {
            let (record_ref, model_record) = resolve_field_record(session, &record)?;
            let expected = write_rules::expected_type_for_record_path(
                session.schema(),
                model_record,
                &path,
                "MUTATION-PATH",
                "MUTATION",
            )?;
            let path = validated_write_path(&path)?;
            ensure_file_guard_for_file(&record, &record_ref.display_path, file.as_deref())?;
            // 值语义只在准备阶段检查一次，始终携带本批次待插入记录上下文。
            let value = coerce_mutation_value(session, &expected, value, pending_records)?;
            let materialized_top_level = materialized_top_level_value(model_record, &path)?;
            Ok(PreparedMutationOp::SetField {
                target: WriteTarget::new(record_ref, path),
                value,
                materialized_top_level,
            })
        }
        MutationOp::UnsetField { record, file, path } => {
            write_rules::expected_type_for_cfd_path(
                session.schema(),
                &record.actual_type,
                &path,
                "MUTATION-PATH",
                "MUTATION",
            )?;
            let path = validated_write_path(&path)?;
            let (record_ref, _) = resolve_field_record(session, &record)?;
            ensure_file_guard_for_file(&record, &record_ref.display_path, file.as_deref())?;
            Ok(PreparedMutationOp::UnsetField {
                target: WriteTarget::new(record_ref, path),
            })
        }
        MutationOp::SetDimensionValue {
            file,
            coordinate,
            expected,
            value,
        } => super::dimension::prepare_dimension_value(
            session,
            coordinate,
            expected,
            Some(value),
            file.as_deref(),
            pending_records,
        ),
        MutationOp::ClearDimensionValue {
            coordinate,
            expected,
        } => super::dimension::prepare_dimension_value(
            session,
            coordinate,
            expected,
            None,
            None,
            pending_records,
        ),
        MutationOp::RenameRecord {
            record,
            file,
            new_id,
        } => {
            ensure_file_guard(session, &record, file.as_deref())?;
            let current_record = session
                .records
                .id_for_coordinate(&record.actual_type, &record.id)
                .ok_or_else(|| {
                    one_mutation_error(
                        "MUTATION-RENAME",
                        format!(
                            "record `{}.{}` was not found",
                            record.actual_type, record.id
                        ),
                    )
                })?;
            ensure_record_id_available(
                session,
                &record.actual_type,
                &new_id,
                Some(current_record),
                "MUTATION-RENAME",
                "MUTATION-RENAME-CONFLICT",
            )?;
            let new_id = RecordId::new(new_id)
                .map_err(|error| one_mutation_error("MUTATION-RENAME", error.to_string()))?;
            let report_file = file.or_else(|| record_file(session, &record).map(ToOwned::to_owned));
            Ok(PreparedMutationOp::RenameRecord {
                record,
                new_id,
                report_file,
            })
        }
        MutationOp::DeleteRecord { record, file } => {
            ensure_file_guard(session, &record, file.as_deref())?;
            let report_file = file.or_else(|| record_file(session, &record).map(ToOwned::to_owned));
            Ok(PreparedMutationOp::DeleteRecord {
                record,
                report_file,
            })
        }
        MutationOp::SwapRecords {
            first,
            second,
            file,
        } => {
            ensure_file_guard(session, &first, file.as_deref())?;
            ensure_file_guard(session, &second, file.as_deref())?;
            let first_file = required_record_file(session, &first, "MUTATION-REORDER")?;
            let second_file = required_record_file(session, &second, "MUTATION-REORDER")?;
            if first_file != second_file {
                return Err(one_mutation_error(
                    "MUTATION-REORDER-CONTAINER",
                    "records must belong to the same source file",
                ));
            }
            Ok(PreparedMutationOp::SwapRecords {
                first,
                second,
                report_file: first_file.to_string(),
            })
        }
        MutationOp::MoveRecord {
            record,
            target_index,
            file,
        } => {
            ensure_file_guard(session, &record, file.as_deref())?;
            let report_file = required_record_file(session, &record, "MUTATION-REORDER")?;
            Ok(PreparedMutationOp::MoveRecord {
                record,
                target_index,
                report_file: report_file.to_string(),
            })
        }
        MutationOp::TransferRecord {
            record,
            destination_file,
            target_index,
            source_file,
        } => {
            ensure_file_guard(session, &record, source_file.as_deref())?;
            let source_file = required_record_file(session, &record, "MUTATION-TRANSFER")?;
            if source_file == destination_file {
                return Err(one_mutation_error(
                    "MUTATION-TRANSFER-FILE",
                    "record transfer requires different source and destination files",
                ));
            }
            Ok(PreparedMutationOp::TransferRecord {
                record,
                destination_file,
                target_index,
            })
        }
    }
}

fn materialized_top_level_value(
    record: &crate::data_model::CfdRecord,
    path: &[CfdPathSegment],
) -> Result<Option<std::sync::Arc<crate::data_model::CfdObject>>, DiagnosticSet> {
    if path.len() <= 1 {
        return Ok(None);
    }
    let root_path = CfdPath {
        segments: path[..1].to_vec(),
    };
    let root = record.value_at_path(&root_path).ok_or_else(|| {
        one_path_error("top-level field was not found while materializing a field")
    })?;
    // 准备阶段只验证路径并共享原值树；显式数组元素修改不复制整个数组。
    validate_nested_path(root, &path[1..])?;
    Ok(Some(std::sync::Arc::clone(&record.object)))
}

fn validate_nested_path(current: &CfdValue, path: &[CfdPathSegment]) -> Result<(), DiagnosticSet> {
    crate::value_path::validate(current, path).map_err(|error| one_path_error(error.message()))
}

pub(super) struct PendingInsertSetRequest<'a> {
    pub(super) insert_file: &'a str,
    pub(super) actual_type: &'a str,
    pub(super) id: &'a str,
    pub(super) fields: &'a mut BTreeMap<String, CfdValue>,
    pub(super) file_guard: Option<&'a str>,
    pub(super) path: &'a [CfdPathSegment],
    pub(super) value: super::MutationValue,
    pub(super) pending_records: &'a BTreeMap<RecordCoordinate, usize>,
}

pub(super) fn prepare_set_on_pending_insert(
    session: &ProjectSession,
    request: PendingInsertSetRequest<'_>,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    let PendingInsertSetRequest {
        insert_file,
        actual_type,
        id,
        fields,
        file_guard,
        path,
        value,
        pending_records,
    } = request;
    ensure_file_guard_for_file(
        &validated_record_coordinate(actual_type, id)?,
        insert_file,
        file_guard,
    )?;
    let expected = write_rules::expected_type_for_cfd_path(
        session.schema(),
        actual_type,
        path,
        "MUTATION-PATH",
        "MUTATION",
    )?;
    let path = validated_write_path(path)?;
    let value = coerce_mutation_value(session, &expected, value, pending_records)?;
    set_pending_insert_value(fields, &path, value)?;
    Ok(PreparedMutationOp::FoldedSetField {
        record: validated_record_coordinate(actual_type, id)?,
        write_file: insert_file.to_string(),
        path: CfdPath {
            segments: path.clone(),
        },
    })
}

pub(super) fn prepare_delete_on_pending_insert(
    insert_file: &str,
    record: &RecordCoordinate,
    file_guard: Option<&str>,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    ensure_file_guard_for_file(record, insert_file, file_guard)?;
    Ok(PreparedMutationOp::FoldedDeleteRecord {
        record: record.clone(),
        write_file: insert_file.to_string(),
    })
}

fn set_pending_insert_value(
    fields: &mut BTreeMap<String, CfdValue>,
    path: &[CfdPathSegment],
    value: CfdValue,
) -> Result<(), DiagnosticSet> {
    let Some(CfdPathSegment::Field(field)) = path.first() else {
        return Err(one_path_error(
            "pending insert paths must start with a field name",
        ));
    };
    if path.len() == 1 {
        fields.insert(field.clone(), value);
        return Ok(());
    }
    let Some(current) = fields.get_mut(field) else {
        return Err(one_path_error(format!(
            "field `{field}` has no materialized value for a nested pending-insert write"
        )));
    };
    set_nested_value(current, &path[1..], value)
}

pub(super) fn set_nested_value(
    current: &mut CfdValue,
    path: &[CfdPathSegment],
    value: CfdValue,
) -> Result<(), DiagnosticSet> {
    crate::value_path::replace(current, path, value)
        .map_err(|error| one_path_error(error.message()))
}

fn prepare_insert_fields(
    session: &ProjectSession,
    actual_type: &str,
    id: &str,
    fields: MutationFields,
    materialization: DefaultMaterialization,
    pending_records: &BTreeMap<RecordCoordinate, usize>,
) -> Result<BTreeMap<String, CfdValue>, DiagnosticSet> {
    let provided = prepare_provided_insert_fields(session, actual_type, fields)?;
    let provided_names = provided.keys().cloned().collect::<BTreeSet<_>>();
    let mut out = default_missing_fields_for_type(
        session.schema(),
        actual_type,
        materialization,
        &provided_names,
    )?;
    out.extend(provided);
    let schema = session.schema();
    for (name, value) in &out {
        let field = schema_field(schema, actual_type, name)?;
        write_rules::validate_value_semantics(
            session,
            schema,
            crate::data_model::ValueValidationRequest::new(
                &field.value_type,
                value,
                crate::data_model::ValueValidationMode::Mutation,
            )
            .with_pending_insert(PendingInsertRef { actual_type, id }),
            Some(pending_records),
            "MUTATION-VALUE",
            "MUTATION-SHAPE",
            "MUTATION",
        )?;
    }
    Ok(out)
}

fn prepare_provided_insert_fields(
    session: &ProjectSession,
    actual_type: &str,
    fields: MutationFields,
) -> Result<BTreeMap<String, CfdValue>, DiagnosticSet> {
    let mut out = BTreeMap::new();
    let schema = session.schema();
    match fields {
        MutationFields::Empty => {}
        MutationFields::Json(fields) => {
            for (name, value) in fields {
                let field = schema_field(schema, actual_type, &name)?;
                out.insert(
                    name,
                    coerce_json_field_value(session, &field.value_type, &value)?,
                );
            }
        }
        MutationFields::Cfd(fields) => {
            for (name, value) in fields {
                let field = schema_field(schema, actual_type, &name)?;
                out.insert(
                    name,
                    coerce_cfd_field_value(session, &field.value_type, value)?,
                );
            }
        }
    }
    Ok(out)
}

fn validated_write_path(
    path: &[CfdPathSegment],
) -> Result<Vec<WriteFieldPathSegment>, DiagnosticSet> {
    if path.is_empty() {
        return Err(one_path_error("mutation path must not be empty"));
    }
    Ok(path.to_vec())
}

fn resolve_field_record<'a>(
    session: &'a ProjectSession,
    coordinate: &RecordCoordinate,
) -> Result<
    (
        &'a crate::indexes::RecordRef,
        &'a crate::data_model::CfdRecord,
    ),
    DiagnosticSet,
> {
    let record_ref = session
        .records
        .get_by_coordinate(&coordinate.actual_type, &coordinate.id)
        .ok_or_else(|| one_path_error("record was not found"))?;
    let record = session
        .model
        .record(record_ref.id)
        .ok_or_else(|| one_path_error("record was not found in the data model"))?;
    Ok((record_ref, record))
}

fn ensure_source_file(session: &ProjectSession, file: &str) -> Result<(), DiagnosticSet> {
    if session.files.source_files().contains(file) {
        return Ok(());
    }
    Err(one_mutation_error(
        "MUTATION-FILE",
        format!("file `{file}` is not a loaded data source"),
    ))
}

fn ensure_file_guard(
    session: &ProjectSession,
    coordinate: &RecordCoordinate,
    file: Option<&str>,
) -> Result<(), DiagnosticSet> {
    let Some(expected_file) = file else {
        return Ok(());
    };
    let Some(actual_file) = record_file(session, coordinate) else {
        return Err(one_mutation_error(
            "MUTATION-FILE-GUARD",
            format!(
                "record `{}.{}` was not found for file guard `{expected_file}`",
                coordinate.actual_type, coordinate.id
            ),
        ));
    };
    if actual_file == expected_file {
        return Ok(());
    }
    Err(one_mutation_error(
        "MUTATION-FILE-GUARD",
        format!(
            "record `{}.{}` belongs to `{actual_file}`, not `{expected_file}`",
            coordinate.actual_type, coordinate.id
        ),
    ))
}

fn ensure_file_guard_for_file(
    coordinate: &RecordCoordinate,
    actual_file: &str,
    expected_file: Option<&str>,
) -> Result<(), DiagnosticSet> {
    let Some(expected_file) = expected_file else {
        return Ok(());
    };
    if actual_file == expected_file {
        return Ok(());
    }
    Err(one_mutation_error(
        "MUTATION-FILE-GUARD",
        format!(
            "record `{}.{}` writes to `{actual_file}`, not `{expected_file}`",
            coordinate.actual_type, coordinate.id
        ),
    ))
}

fn ensure_type_can_insert(
    session: &ProjectSession,
    actual_type: &str,
) -> Result<(), DiagnosticSet> {
    let schema = session.schema();
    let Some(schema_type) = schema.resolve_type(actual_type) else {
        return Err(one_mutation_error(
            "MUTATION-TYPE",
            format!("unknown insert type `{actual_type}`"),
        ));
    };
    if schema_type.is_abstract {
        return Err(one_mutation_error(
            "MUTATION-TYPE",
            format!("abstract type `{actual_type}` cannot be inserted"),
        ));
    }
    if !schema_type.is_table() {
        return Err(one_mutation_error(
            "MUTATION-TYPE",
            format!("only table records can be inserted: `{actual_type}`"),
        ));
    }
    Ok(())
}

fn ensure_record_id_available(
    session: &ProjectSession,
    actual_type: &str,
    id: &str,
    current_record: Option<crate::data_model::CfdRecordHandle>,
    code: &'static str,
    conflict_code: &'static str,
) -> Result<(), DiagnosticSet> {
    write_rules::ensure_record_id_available_with_conflict_code(
        session,
        actual_type,
        id,
        current_record,
        code,
        conflict_code,
        "MUTATION",
    )
}

fn record_file<'a>(session: &'a ProjectSession, coordinate: &RecordCoordinate) -> Option<&'a str> {
    session.file_for_record(&coordinate.actual_type, &coordinate.id)
}

fn required_record_file<'a>(
    session: &'a ProjectSession,
    coordinate: &RecordCoordinate,
    code: &'static str,
) -> Result<&'a str, DiagnosticSet> {
    record_file(session, coordinate).ok_or_else(|| {
        one_mutation_error(
            code,
            format!(
                "record `{}.{}` was not found",
                coordinate.actual_type, coordinate.id
            ),
        )
    })
}

#[cfg(test)]
mod deferred_path_tests {
    use super::*;

    #[test]
    fn borrowed_validation_matches_materialized_path_errors() {
        let values = [
            CfdValue::OptionNone,
            CfdValue::OptionSome(Box::new(CfdValue::Array(vec![CfdValue::Int(1)]))),
            CfdValue::Array(vec![CfdValue::Int(2)]),
        ];
        let paths = [
            vec![],
            vec![CfdPathSegment::Index(0)],
            vec![CfdPathSegment::Index(1)],
            vec![
                CfdPathSegment::Index(0),
                CfdPathSegment::Field("missing".into()),
            ],
        ];
        for value in values {
            for path in &paths {
                let borrowed = validate_nested_path(&value, path);
                let materialized = set_nested_value(&mut value.clone(), path, CfdValue::Int(9));
                assert_eq!(format!("{borrowed:?}"), format!("{materialized:?}"));
            }
        }
    }
}
