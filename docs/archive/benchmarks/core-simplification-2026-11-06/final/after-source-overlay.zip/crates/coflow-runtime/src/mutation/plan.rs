use std::collections::BTreeMap;

use crate::api::{Diagnostic, DiagnosticSet};

use crate::{ProjectSession, RecordCoordinate};

use super::prepare::{
    prepare_delete_on_pending_insert, prepare_one, prepare_set_on_pending_insert,
    PendingInsertSetRequest,
};
use super::types::PreparedMutationOp;
use super::{MutationFailedOp, MutationOp, MutationRequest};

#[derive(Debug)]
pub(super) struct PlannedMutationOp {
    pub(super) index: usize,
    pub(super) op: PreparedMutationOp,
}

pub(super) fn plan_mutations(
    session: &ProjectSession,
    request: MutationRequest,
) -> (Vec<PlannedMutationOp>, Vec<MutationFailedOp>, bool, bool) {
    let MutationRequest {
        stop_on_write_error,
        ops,
    } = request;
    if ops.len() > 1 {
        if let Some((index, op)) = ops.iter().enumerate().find(|(_, op)| {
            matches!(
                op,
                MutationOp::SwapRecords { .. }
                    | MutationOp::MoveRecord { .. }
                    | MutationOp::TransferRecord { .. }
            )
        }) {
            let diagnostics = DiagnosticSet::one(Diagnostic::error(
                "MUTATION-REORDER-BATCH",
                "MUTATION",
                "record reorder or transfer must be the only operation in a mutation request",
            ));
            return (
                Vec::new(),
                vec![MutationFailedOp::from_diagnostics(
                    index,
                    mutation_op_name(op),
                    diagnostics,
                )],
                false,
                true,
            );
        }
    }
    let mut planned = Vec::<PlannedMutationOp>::new();
    let mut pending_inserts = BTreeMap::<RecordCoordinate, usize>::new();
    let mut failed = Vec::new();
    let mut write_ok = true;

    for (index, op) in ops.into_iter().enumerate() {
        let op_name = mutation_op_name(&op);
        let insert_op = matches!(op, MutationOp::InsertRecord { .. });
        let result = prepare_planned_op(session, &mut planned, &mut pending_inserts, op);

        match result {
            Ok(op) => planned.push(PlannedMutationOp { index, op }),
            Err(diagnostics) => {
                write_ok = false;
                let terminal = is_terminal_prepare_error(insert_op, &diagnostics);
                failed.push(MutationFailedOp::from_diagnostics(
                    index,
                    op_name,
                    diagnostics,
                ));
                if stop_on_write_error || terminal {
                    return (Vec::new(), failed, false, true);
                }
            }
        }
    }
    (planned, failed, write_ok, false)
}

fn prepare_planned_op(
    session: &ProjectSession,
    planned: &mut [PlannedMutationOp],
    pending_inserts: &mut BTreeMap<RecordCoordinate, usize>,
    op: MutationOp,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    match op {
        MutationOp::SetField {
            record,
            file,
            path,
            value,
        } => prepare_set_field(
            session,
            planned,
            pending_inserts,
            MutationOp::SetField {
                record,
                file,
                path,
                value,
            },
        ),
        MutationOp::UnsetField { record, file, path } => prepare_one(
            session,
            MutationOp::UnsetField { record, file, path },
            pending_inserts,
        ),
        op @ (MutationOp::RestoreRecord { .. }
        | MutationOp::SetDimensionValue { .. }
        | MutationOp::ClearDimensionValue { .. }
        | MutationOp::SwapRecords { .. }
        | MutationOp::MoveRecord { .. }
        | MutationOp::TransferRecord { .. }) => prepare_one(session, op, pending_inserts),
        MutationOp::InsertRecord {
            file,
            actual_type,
            id,
            fields,
            materialization,
        } => prepare_insert(
            session,
            planned.len(),
            pending_inserts,
            MutationOp::InsertRecord {
                file,
                actual_type,
                id,
                fields,
                materialization,
            },
        ),
        // 改名操作由结构序列单独准备，前一段插入已进入候选模型。
        op @ MutationOp::RenameRecord { .. } => prepare_one(session, op, pending_inserts),
        MutationOp::DeleteRecord { record, file } => {
            let Some(insert_index) = pending_inserts.get(&record).copied() else {
                return prepare_one(
                    session,
                    MutationOp::DeleteRecord { record, file },
                    pending_inserts,
                );
            };
            fold_pending_insert_delete(
                planned,
                pending_inserts,
                insert_index,
                &record,
                file.as_deref(),
            )
        }
    }
}

fn prepare_set_field(
    session: &ProjectSession,
    planned: &mut [PlannedMutationOp],
    pending_inserts: &BTreeMap<RecordCoordinate, usize>,
    op: MutationOp,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    let MutationOp::SetField {
        record,
        file,
        path,
        value,
    } = op
    else {
        return Err(mutation_invariant_error(
            "set-field preparation received a different operation",
        ));
    };
    let Some(insert_index) = pending_inserts.get(&record).copied() else {
        return prepare_one(
            session,
            MutationOp::SetField {
                record,
                file,
                path,
                value,
            },
            pending_inserts,
        );
    };
    let pending_insert = planned.get_mut(insert_index).ok_or_else(|| {
        mutation_invariant_error("pending insert index is outside the planned operation list")
    })?;
    let PreparedMutationOp::InsertRecord {
        file: insert_file,
        actual_type,
        id,
        fields,
        ..
    } = &mut pending_insert.op
    else {
        return Err(mutation_invariant_error(
            "pending insert index does not identify an insert operation",
        ));
    };
    prepare_set_on_pending_insert(
        session,
        PendingInsertSetRequest {
            insert_file,
            actual_type,
            id,
            fields,
            file_guard: file.as_deref(),
            path: &path,
            value,
            pending_records: pending_inserts,
        },
    )
}

fn prepare_insert(
    session: &ProjectSession,
    planned_len: usize,
    pending_inserts: &mut BTreeMap<RecordCoordinate, usize>,
    op: MutationOp,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    let MutationOp::InsertRecord {
        ref actual_type,
        ref id,
        ..
    } = op
    else {
        return Err(mutation_invariant_error(
            "insert preparation received a non-insert operation",
        ));
    };
    let coordinate = RecordCoordinate::try_new(actual_type, id).map_err(|error| {
        DiagnosticSet::one(Diagnostic::error(
            "MUTATION-COORDINATE",
            "MUTATION",
            error.to_string(),
        ))
    })?;
    if pending_inserts.contains_key(&coordinate) {
        return Err(DiagnosticSet::one(Diagnostic::error(
            "MUTATION-INSERT-CONFLICT",
            "MUTATION",
            format!(
                "record `{}.{}` is inserted more than once in the same mutation",
                coordinate.actual_type, coordinate.id
            ),
        )));
    }
    let prepared = prepare_one(session, op, pending_inserts)?;
    if matches!(prepared, PreparedMutationOp::InsertRecord { .. }) {
        pending_inserts.insert(coordinate, planned_len);
    }
    Ok(prepared)
}

fn fold_pending_insert_delete(
    planned: &mut [PlannedMutationOp],
    pending_inserts: &mut BTreeMap<RecordCoordinate, usize>,
    insert_index: usize,
    record: &RecordCoordinate,
    file_guard: Option<&str>,
) -> Result<PreparedMutationOp, DiagnosticSet> {
    let Some(pending_insert) = planned.get(insert_index) else {
        return Err(mutation_invariant_error(
            "pending delete index is outside the planned operation list",
        ));
    };
    let PreparedMutationOp::InsertRecord { file, .. } = &pending_insert.op else {
        return Err(mutation_invariant_error(
            "pending delete index does not identify an insert operation",
        ));
    };
    let insert_file = file.clone();
    let folded = prepare_delete_on_pending_insert(&insert_file, record, file_guard)?;
    let Some(pending_insert) = planned.get_mut(insert_index) else {
        return Err(mutation_invariant_error(
            "pending delete index disappeared during planning",
        ));
    };
    pending_insert.op = PreparedMutationOp::CancelledInsert {
        record: record.clone(),
        write_file: insert_file,
    };
    pending_inserts.remove(record);
    Ok(folded)
}

fn mutation_invariant_error(message: &str) -> DiagnosticSet {
    DiagnosticSet::one(Diagnostic::error(
        "MUTATION-TXN-INVARIANT",
        "MUTATION",
        message,
    ))
}

pub(super) const fn mutation_op_name(op: &MutationOp) -> &'static str {
    match op {
        MutationOp::RestoreRecord { .. } => "restore_record",
        MutationOp::InsertRecord { .. } => "insert_record",
        MutationOp::SetField { .. } => "set_field",
        MutationOp::UnsetField { .. } => "unset_field",
        MutationOp::SetDimensionValue { .. } => "set_dimension_value",
        MutationOp::ClearDimensionValue { .. } => "clear_dimension_value",
        MutationOp::RenameRecord { .. } => "rename_record",
        MutationOp::DeleteRecord { .. } => "delete_record",
        MutationOp::SwapRecords { .. } => "swap_records",
        MutationOp::MoveRecord { .. } => "move_record",
        MutationOp::TransferRecord { .. } => "transfer_record",
    }
}

fn is_terminal_prepare_error(insert_op: bool, diagnostics: &DiagnosticSet) -> bool {
    diagnostics.iter().any(|diagnostic| {
        diagnostic.code == "MUTATION-TXN-INVARIANT"
            || (insert_op && diagnostic.code == "MUTATION-INSERT-CONFLICT")
    })
}
