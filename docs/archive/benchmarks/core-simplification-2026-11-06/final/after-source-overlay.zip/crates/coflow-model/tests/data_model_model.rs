#![allow(
    clippy::expect_used,
    clippy::needless_raw_string_hashes,
    clippy::panic,
    clippy::panic_in_result_fn,
    clippy::unwrap_used
)]

#[path = "data_model_common/mod.rs"]
mod common;
use common::*;
use std::path::PathBuf;

#[test]
fn data_model_applies_defaults_and_builds_record_id_indexes_without_running_check() {
    let schema = compile_schema(
        r#"
            const DEFAULT_NAME = "unknown";
            enum Rarity { Common = 0, Rare = 10, }
            table Item {
                name: string = DEFAULT_NAME;
                rarity: Rarity = Rarity::Common;
                tags: [string] = [];
                attrs: {string: int} = {};
                check Valid { id != ""; }
            }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "item_1",
        "Item",
        std::iter::empty::<(&str, LoadedValueDraft)>(),
    );
    let model = builder.build().expect("data model should build");

    let item_id = record_id_at(&model, 0);
    let table = model.table("Item").expect("item table");
    assert_eq!(table.records, vec![item_id]);
    assert_eq!(table.primary_index.get("item_1"), Some(&item_id));
    assert_eq!(
        model.lookup_assignable(&schema, "Item", "item_1"),
        Some(item_id)
    );

    let record = model.record(item_id).expect("record");
    assert_eq!(record.id(), "item_1");
    assert_eq!(
        record.field("name"),
        Some(&CfdValue::String("unknown".to_string()))
    );
    assert_eq!(
        record.field("rarity"),
        Some(&CfdValue::Enum(
            CfdEnumValue::try_new("Rarity", Some("Common"), 0).unwrap()
        ))
    );
    assert_eq!(record.field("tags"), Some(&CfdValue::Array(Vec::new())));
    assert_eq!(record.field("attrs"), Some(&CfdValue::Dict(Vec::new())));
}

#[test]
fn invalid_dimension_values_preserve_the_overlay_origin() {
    let schema = compile_schema(
        r#"
            table Item {
                @dimension("platform")
                value: int;
            }
        "#,
    );
    let origin = RecordOrigin::File {
        path: PathBuf::from("dimensions/platform.cfd"),
        span: Some(TextSpan {
            start_line: 4,
            start_character: 2,
            end_line: 4,
            end_character: 12,
        }),
    };
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("item", "Item", [("value", LoadedValueDraft::from(1_i64))]);
    builder.add_dimension_value_draft(DimensionValueDraft {
        source_type: TypeName::new("Item").unwrap(),
        source_id: RecordId::new("item").unwrap(),
        field: FieldName::new("value").unwrap(),
        dimension: DimensionName::new("platform").unwrap(),
        variant: VariantName::new("pc").unwrap(),
        value: LoadedValueDraft::from("not-an-int"),
        origin: origin.clone(),
    });

    let diagnostics = builder.build().expect_err("invalid overlay value");
    let diagnostic = diagnostic_with_code(&diagnostics, CfdErrorCode::TypeMismatch);
    assert_eq!(
        diagnostic
            .primary
            .as_ref()
            .and_then(|primary| primary.origin.as_ref()),
        Some(&origin)
    );
}

#[test]
fn data_model_reuses_shared_schema_default_subgraphs() {
    let schema = compile_schema(
        r#"
            data Leaf { value: int = 7; }
            data Branch { leaf: Leaf = {}; }
            table Root { left: Branch = {}; right: Branch = {}; }
        "#,
    );
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "root",
        "Root",
        std::iter::empty::<(&str, LoadedValueDraft)>(),
    );

    let model = builder.build().expect("shared default graph builds");
    let root = model
        .records()
        .next()
        .map(|(_, record)| record)
        .expect("root record");
    for field in ["left", "right"] {
        let Some(CfdValue::Object(branch)) = root.field(field) else {
            panic!("{field} branch");
        };
        let Some(CfdValue::Object(leaf)) = branch.field("leaf") else {
            panic!("leaf object");
        };
        assert_eq!(leaf.field("value"), Some(&CfdValue::Int(7)));
    }
}

#[test]
fn shared_explicit_defaults_keep_record_context_and_declaration_identity() {
    let schema = compile_schema(
        r#"
            table Base {}
            table Derived : Base {}
            table Sibling : Base {}
            data Node { child: Option<Node> = Some(Node { child: None }); }
            table First {
                labels: [string] = [f"first {self.id}"];
                targets: [&Base] = [&Derived::target];
                nodes: [Node] = [Node { child: None }];
            }
            table Second { labels: [string] = [f"second {self.id}"]; }
        "#,
    );
    let build = |target_type| {
        let mut builder = CfdDataModel::builder(&schema);
        for (id, type_name) in [
            ("target", target_type),
            ("one", "First"),
            ("two", "First"),
            ("three", "Second"),
        ] {
            builder.add_record(
                id,
                type_name,
                std::iter::empty::<(&str, LoadedValueDraft)>(),
            );
        }
        builder.build()
    };
    let model = build("Derived").expect("shared defaults build");
    for (id, type_name, prefix) in [
        ("one", "First", "first"),
        ("two", "First", "first"),
        ("three", "Second", "second"),
    ] {
        let record = model
            .record_by_type_id(type_name, id)
            .and_then(|handle| model.record(handle))
            .expect("record");
        let Some(CfdValue::Array(labels)) = record.field("labels") else {
            panic!("labels");
        };
        assert!(matches!(
            &labels[0], CfdValue::FormattedString(value) if value.rendered == format!("{prefix} {id}")
        ));
        if type_name == "First" {
            let Some(CfdValue::Array(nodes)) = record.field("nodes") else {
                panic!("nodes");
            };
            let CfdValue::Object(node) = &nodes[0] else {
                panic!("node");
            };
            assert_eq!(node.field("child"), Some(&CfdValue::OptionNone));
            assert_eq!(
                record.field("targets"),
                Some(&CfdValue::Array(vec![CfdValue::Ref(
                    RecordId::new("target").expect("target id")
                )]))
            );
        }
    }
    let diagnostics = build("Sibling").expect_err("explicit reference type remains Derived");
    assert_has_code(&diagnostics, CfdErrorCode::RefTargetTypeMismatch);
}

#[test]
fn flag_default_dictionary_keys_match_explicit_masks_and_builtin_members() {
    let schema = compile_schema(
        r#"
            @flag enum Permission { Read = 1, Write = 2, Execute = 4 }
            table Item {
                keys: {Permission: int} = {
                    Permission::None: 0,
                    Permission::Read: 1,
                    Permission::Read | Permission::Write: 3,
                    Permission::Everything: 7,
                };
                empty: Permission = Permission::None;
                full: Permission = Permission::Everything;
            }
        "#,
    );
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "defaults",
        "Item",
        std::iter::empty::<(&str, LoadedValueDraft)>(),
    );
    builder.add_record(
        "cached",
        "Item",
        std::iter::empty::<(&str, LoadedValueDraft)>(),
    );
    builder.add_record(
        "explicit",
        "Item",
        [(
            "keys",
            LoadedValueDraft::dict([0, 1, 3, 7].map(|mask| {
                (
                    LoadedDictKeyDraft::EnumValue {
                        enum_name: "Permission".into(),
                        value: mask,
                    },
                    LoadedValueDraft::Int(mask),
                )
            })),
        )],
    );
    let model = builder.build().expect("flag mask defaults build");
    let defaults = model
        .record_by_type_id("Item", "defaults")
        .and_then(|handle| model.record(handle))
        .expect("default record");
    let explicit = model
        .record_by_type_id("Item", "explicit")
        .and_then(|handle| model.record(handle))
        .expect("explicit record");
    assert_eq!(defaults.field("keys"), explicit.field("keys"));
    let cached = model
        .record_by_type_id("Item", "cached")
        .and_then(|handle| model.record(handle))
        .expect("cached default record");
    assert_eq!(cached.field("keys"), explicit.field("keys"));
    for (field, mask) in [("empty", 0), ("full", 7)] {
        let Some(CfdValue::Enum(value)) = defaults.field(field) else {
            panic!("flag value");
        };
        assert_eq!(value.value, mask);
        assert!(value.variant.is_none());
    }
}

#[test]
fn dimension_field_lookup_reads_record_owned_overlay() {
    let schema = compile_schema(
        r#"
            table Item {
                @dimension("platform")
                name: string;
            }
        "#,
    );
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "potion",
        "Item",
        [("name", LoadedValueDraft::from("Potion"))],
    );
    builder.add_dimension_value_draft(DimensionValueDraft {
        source_type: TypeName::new("Item").unwrap(),
        source_id: RecordId::new("potion").unwrap(),
        field: FieldName::new("name").unwrap(),
        dimension: DimensionName::new("platform").unwrap(),
        variant: VariantName::new("pc").unwrap(),
        value: LoadedValueDraft::from("PC Potion"),
        origin: RecordOrigin::None,
    });
    let model = builder.build().expect("data model should build");
    let item_id = model
        .lookup_assignable(&schema, "Item", "potion")
        .expect("item");

    let resolved = model
        .dimension_field_value(&schema, item_id, "name", "platform", "pc")
        .expect("variant lookup should resolve");

    assert!(matches!(
        resolved,
        DimensionValueLookup::Value {
            value: CfdValue::String(value),
            origin: RecordOrigin::None,
        } if value == "PC Potion"
    ));
    assert_eq!(model.record_count(), 1);
}

#[test]
fn dimension_refs_are_precomputed_with_typed_coordinates() {
    let schema = compile_schema(
        r#"
            table Item { name: string; }
            table Offer {
                @dimension("platform")
                item: &Item;
            }
        "#,
    );
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "potion",
        "Item",
        [("name", LoadedValueDraft::from("Potion"))],
    );
    builder.add_record(
        "starter",
        "Offer",
        [("item", LoadedValueDraft::record_ref("potion"))],
    );
    builder.add_dimension_value_draft(DimensionValueDraft {
        source_type: TypeName::new("Offer").unwrap(),
        source_id: RecordId::new("starter").unwrap(),
        field: FieldName::new("item").unwrap(),
        dimension: DimensionName::new("platform").unwrap(),
        variant: VariantName::new("pc").unwrap(),
        value: LoadedValueDraft::record_ref("potion"),
        origin: RecordOrigin::None,
    });

    let model = builder.build().expect("data model should build");
    let offer = model
        .lookup_assignable(&schema, "Offer", "starter")
        .expect("offer");
    let item = model
        .lookup_assignable(&schema, "Item", "potion")
        .expect("item");
    let edges = model.ref_edges_from_host(offer).collect::<Vec<_>>();

    assert_eq!(edges.len(), 2);
    assert!(edges.iter().any(|edge| edge.site.dimension.is_none()));
    let overlay = edges
        .iter()
        .find(|edge| edge.site.dimension.is_some())
        .expect("overlay ref edge");
    let coordinate = overlay.site.dimension.as_ref().unwrap();
    assert_eq!(coordinate.field.as_str(), "item");
    assert_eq!(coordinate.dimension.as_str(), "platform");
    assert_eq!(coordinate.variant.as_str(), "pc");
    assert_eq!(overlay.target, item);
    assert_eq!(model.ref_edges_to_target(item).count(), 2);
}

#[test]
fn dimension_field_lookup_uses_singleton_owner_record() {
    let schema = compile_schema(
        r#"
            singleton UiText {
                @localized
                welcome: string;
            }
        "#,
    );
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "UiText",
        "UiText",
        [("welcome", LoadedValueDraft::from("Welcome"))],
    );
    builder.add_dimension_value_draft(DimensionValueDraft {
        source_type: TypeName::new("UiText").unwrap(),
        source_id: RecordId::new("UiText").unwrap(),
        field: FieldName::new("welcome").unwrap(),
        dimension: DimensionName::new("language").unwrap(),
        variant: VariantName::new("zh").unwrap(),
        value: LoadedValueDraft::from("欢迎"),
        origin: RecordOrigin::None,
    });
    let model = builder.build().expect("data model should build");
    let singleton_id = model
        .lookup_assignable(&schema, "UiText", "UiText")
        .expect("singleton");

    let resolved = model
        .dimension_field_value(&schema, singleton_id, "welcome", "language", "zh")
        .expect("singleton variant lookup should resolve by field name");

    assert!(matches!(
        resolved,
        DimensionValueLookup::Value {
            value: CfdValue::String(value),
            ..
        } if value == "欢迎"
    ));
}

#[test]
fn object_typed_record_refs_resolve_by_expected_type() {
    let schema = compile_schema(
        r#"
            abstract table Reward {}
            table ItemReward : Reward { count: int; }
            table CurrencyReward : Reward { amount: int; }
            table Drop {
                reward: &Reward;
                item_reward: &ItemReward;
            }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "reward_1",
        "ItemReward",
        [("count", LoadedValueDraft::from(1_i64))],
    );
    builder.add_record(
        "drop_1",
        "Drop",
        [
            ("reward", LoadedValueDraft::record_ref("reward_1")),
            ("item_reward", LoadedValueDraft::record_ref("reward_1")),
        ],
    );
    let model = builder.build().expect("data model should build");
    let reward_id = record_id_at(&model, 0);
    let drop_id = record_id_at(&model, 1);

    assert_eq!(
        model.lookup_assignable(&schema, "Reward", "reward_1"),
        Some(reward_id)
    );
    assert_eq!(
        model
            .records_assignable_to(&schema, "Reward")
            .map(|(id, _)| id)
            .collect::<Vec<_>>(),
        vec![reward_id]
    );
    assert_eq!(
        model
            .record(drop_id)
            .and_then(|record| record.field("reward")),
        Some(&CfdValue::record_ref("reward_1").unwrap())
    );
    let _ = reward_id;
}

#[test]
fn parent_record_ids_do_not_satisfy_child_typed_refs() {
    let schema = compile_schema(
        r#"
            table Base { name: string; }
            table Child : Base { power: int; }
            table Holder { child: &Child; }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("base_1", "Base", [("name", LoadedValueDraft::from("base"))]);
    builder.add_record(
        "holder_1",
        "Holder",
        [("child", LoadedValueDraft::record_ref("base_1"))],
    );

    let err = builder
        .build()
        .expect_err("parent-typed ref should not satisfy child field");
    assert_has_code(&err, CfdErrorCode::RefTargetTypeMismatch);
}

#[test]
fn inline_objects_use_declared_type_when_not_polymorphic() {
    let schema = compile_schema(
        r#"
            data Stats { hp: int; speed: float = 1.0; }
            table Monster { stats: Stats; }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "monster_1",
        "Monster",
        [(
            "stats",
            LoadedValueDraft::object_with_declared_type([("hp", LoadedValueDraft::from(100_i64))]),
        )],
    );
    let model = builder.build().expect("data model should build");
    let monster_id = record_id_at(&model, 0);
    let Some(CfdValue::Object(stats)) = model
        .record(monster_id)
        .and_then(|record| record.field("stats"))
    else {
        panic!("expected stats object");
    };
    assert_eq!(stats.actual_type(), "Stats");
    assert_eq!(stats.field("speed"), Some(&CfdValue::Float(1.0)));
}

#[test]
fn ref_type_rejects_inline_objects() {
    let schema = compile_schema(
        r#"
            table Item { name: string; }
            table Holder {
                item: &Item;
            }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "holder",
        "Holder",
        [(
            "item",
            LoadedValueDraft::object_with_declared_type([(
                "name",
                LoadedValueDraft::from("Sword"),
            )]),
        )],
    );

    let err = builder
        .build()
        .expect_err("ref type should reject inline object");
    assert_has_code(&err, CfdErrorCode::TypeMismatch);
    assert!(
        err.diagnostics
            .iter()
            .any(|diagnostic| diagnostic.message.contains("Item")),
        "expected ref type diagnostic, got {err:?}"
    );
}

#[test]
fn plain_object_fields_reject_record_refs() {
    let schema = compile_schema(
        r#"
            data Item { name: string; }
            table Holder {
                item: Item;
                items: [Item];
                by_name: {string: Item};
            }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("sword", "Item", [("name", LoadedValueDraft::from("Sword"))]);
    builder.add_record(
        "holder",
        "Holder",
        [
            ("item", LoadedValueDraft::record_ref("sword")),
            (
                "items",
                LoadedValueDraft::Array(vec![LoadedValueDraft::record_ref("sword")]),
            ),
            (
                "by_name",
                LoadedValueDraft::dict([(
                    LoadedDictKeyDraft::from("main"),
                    LoadedValueDraft::record_ref("sword"),
                )]),
            ),
        ],
    );

    let err = builder
        .build()
        .expect_err("plain object fields should reject record refs");
    assert_has_code(&err, CfdErrorCode::TypeMismatch);
}

#[test]
fn semantic_edges_report_data_model_diagnostics() {
    let schema = compile_schema(
        r#"
            enum Rarity { Common, Rare, }
            table Item {
                rarity: Rarity;
                maybe: Option<int>;
                attrs: {string: int};
            }
        "#,
    );

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "item_1",
        "Item",
        [
            ("unknown", LoadedValueDraft::from(1_i64)),
            (
                "rarity",
                LoadedValueDraft::enum_variant("Rarity", "Missing"),
            ),
            (
                "attrs",
                LoadedValueDraft::dict([
                    (LoadedDictKeyDraft::from("x"), LoadedValueDraft::from(1_i64)),
                    (LoadedDictKeyDraft::from("x"), LoadedValueDraft::from(2_i64)),
                ]),
            ),
        ],
    );

    let err = builder.build().expect_err("data errors");
    assert_has_code(&err, CfdErrorCode::UnknownField);
    assert_has_code(&err, CfdErrorCode::InvalidEnumVariant);
    assert_has_code(&err, CfdErrorCode::DuplicateDictKey);
}

#[test]
fn omitted_option_requires_an_explicit_default() {
    let schema =
        compile_schema("table Item { required: Option<int>; optional: Option<int> = None; }");
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "item",
        "Item",
        std::iter::empty::<(&str, LoadedValueDraft)>(),
    );
    let output = builder.build_partial().expect("editable missing field");
    let diagnostic = diagnostic_with_code(&output.diagnostics, CfdErrorCode::MissingRequiredField);
    assert_eq!(
        primary_path_segments(diagnostic),
        &[CfdPathSegment::Field("required".into())]
    );
    let (_, item) = output.model.records().next().expect("item record");
    assert_eq!(item.field("required"), None);
    assert_eq!(item.field("optional"), Some(&CfdValue::OptionNone));

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("item", "Item", [("required", LoadedValueDraft::OptionNone)]);
    assert!(builder.build().is_ok(), "explicit None satisfies presence");
}

#[test]
fn partial_build_keeps_records_with_only_missing_required_fields() {
    let schema = compile_schema("table Item { name: string; value: int; }");
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("item", "Item", [("value", LoadedValueDraft::from(1_i64))]);

    let output = builder
        .build_partial()
        .expect("a missing field can be repaired later");
    assert_has_code(&output.diagnostics, CfdErrorCode::MissingRequiredField);
    assert_eq!(CfdErrorCode::MissingRequiredField.as_str(), "DATA-006");
    let item_id = output
        .model
        .lookup_assignable(&schema, "Item", "item")
        .expect("record remains addressable");
    let item = output.model.record(item_id).expect("item");
    assert_eq!(item.field("name"), None);
    assert_eq!(item.field("value"), Some(&CfdValue::Int(1)));
}

#[test]
fn partial_build_still_rejects_non_representable_data_errors() {
    let schema = compile_schema("table Item { value: int; }");
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "item",
        "Item",
        [
            ("value", LoadedValueDraft::from(1_i64)),
            ("unknown", LoadedValueDraft::from(2_i64)),
        ],
    );

    let diagnostics = builder
        .build_partial()
        .expect_err("unknown fields must remain blocking");
    assert_has_code(&diagnostics, CfdErrorCode::UnknownField);
}

#[test]
fn duplicate_keys_report_record_level_id_paths() {
    let schema = compile_schema("table Item { value: int; }");

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("same", "Item", [("value", LoadedValueDraft::from(1_i64))]);
    builder.add_record("same", "Item", [("value", LoadedValueDraft::from(2_i64))]);

    let err = builder.build().expect_err("duplicate concrete key");
    let diag = diagnostic_with_code(&err, CfdErrorCode::DuplicateId);
    assert_eq!(
        diag.primary.as_ref().map(|label| label.path.clone()),
        Some(CfdPath::root().field("id"))
    );
    assert_eq!(diag.related.len(), 1);
}

#[test]
fn empty_record_ids_are_rejected() {
    let schema = compile_schema("table Item { value: int; }");

    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record("", "Item", [("value", LoadedValueDraft::from(1_i64))]);

    let err = builder.build().expect_err("empty key should fail");
    let diag = diagnostic_with_code(&err, CfdErrorCode::MissingIdField);
    assert_eq!(
        diag.primary.as_ref().map(|label| label.path.clone()),
        Some(CfdPath::root().field("id"))
    );
}

#[test]
fn non_identifier_record_ids_are_rejected() {
    let schema = compile_schema("table Item { value: int; }");

    for key in ["123", "fire-ball", "fire.ball", "type"] {
        let mut builder = CfdDataModel::builder(&schema);
        builder.add_record(key, "Item", [("value", LoadedValueDraft::from(1_i64))]);

        let Err(err) = builder.build() else {
            panic!("`{key}` should fail as a record key")
        };
        assert_has_code(&err, CfdErrorCode::InvalidRecordId);
    }
}

#[test]
fn record_value_lookup_traverses_object_array_and_dict_paths() {
    let schema = compile_schema(
        r#"
            data Nested { value: int; }
            table Item {
                nested: Nested;
                items: [Nested];
                entries: {string: Nested};
            }
        "#,
    );
    let nested = |value| {
        LoadedValueDraft::object_with_declared_type([("value", LoadedValueDraft::from(value))])
    };
    let mut builder = CfdDataModel::builder(&schema);
    builder.add_record(
        "item",
        "Item",
        [
            ("nested", nested(1_i64)),
            ("items", LoadedValueDraft::Array(vec![nested(2_i64)])),
            (
                "entries",
                LoadedValueDraft::dict([(LoadedDictKeyDraft::from("slot"), nested(3_i64))]),
            ),
        ],
    );
    let model = builder.build().expect("model builds");
    let record = model
        .record(record_id_at(&model, 0))
        .expect("record exists");

    assert_eq!(
        record.value_at_path(&CfdPath::root().field("nested").field("value")),
        Some(&CfdValue::Int(1))
    );
    assert_eq!(
        record.value_at_path(&CfdPath::root().field("items").index(0).field("value")),
        Some(&CfdValue::Int(2))
    );
    assert_eq!(
        record.value_at_path(
            &CfdPath::root()
                .field("entries")
                .dict_key_value(&CfdDictKey::String("slot".to_string()))
                .field("value")
        ),
        Some(&CfdValue::Int(3))
    );
    assert_eq!(
        record.value_at_path(&CfdPath::root().field("items").index(1)),
        None
    );
}
