use crate::{LoadedDictKeyDraft, LoadedValueDraft};
use coflow_language::cft::{CftSchema, CftValueType};

use super::diagnostics::{missing_boundary, syntax, type_mismatch, CellValueDiagnostics};
use super::scan::{find_top_level_char, split_top_level, strip_outer_pair};
use super::strings::parse_string;
use super::{parse_value, ValueContext};

pub(super) fn parse_array(
    schema: &CftSchema,
    inner: &CftValueType,
    text: &str,
    context: ValueContext,
) -> Result<LoadedValueDraft, CellValueDiagnostics> {
    let explicit = strip_outer_pair(text, '[', ']');
    if explicit.is_none() && !context.is_root() {
        return Err(missing_boundary("nested array must use `[]`"));
    }
    let content = explicit.map_or(text, |inner| inner).trim();
    if content.is_empty() {
        return Ok(LoadedValueDraft::Array(Vec::new()));
    }

    let mut out = Vec::new();
    for item in split_top_level(content, '|')? {
        reject_comma_array_item(inner, item)?;
        out.push(parse_value(schema, inner, item, ValueContext::Nested)?);
    }
    Ok(LoadedValueDraft::Array(out))
}

fn reject_comma_array_item(inner: &CftValueType, item: &str) -> Result<(), CellValueDiagnostics> {
    if find_top_level_char(item, ',')?.is_some() {
        return match inner {
            CftValueType::Object(_) | CftValueType::Dict(_, _) => Err(missing_boundary(
                "array elements with composite values must use boundaries",
            )),
            _ => Err(syntax("array elements must be separated with `|`")),
        };
    }
    Ok(())
}

pub(super) fn parse_dict(
    schema: &CftSchema,
    key: &CftValueType,
    value: &CftValueType,
    text: &str,
    context: ValueContext,
) -> Result<LoadedValueDraft, CellValueDiagnostics> {
    let explicit = strip_outer_pair(text, '{', '}');
    if explicit.is_none() && !context.is_root() {
        return Err(missing_boundary("nested dict must use `{}`"));
    }
    let content = explicit.map_or(text, |inner| inner).trim();
    if content.is_empty() {
        return Ok(LoadedValueDraft::dict(std::iter::empty()));
    }

    let mut out = Vec::new();
    for entry in split_top_level(content, ',')? {
        let Some(colon) = find_top_level_char(entry, ':')? else {
            return Err(syntax("dict entry is missing `:`"));
        };
        let key_text = entry[..colon].trim();
        let value_text = entry[colon + 1..].trim();
        out.push((
            parse_dict_key(schema, key, key_text)?,
            parse_value(schema, value, value_text, ValueContext::Nested)?,
        ));
    }
    Ok(LoadedValueDraft::dict(out))
}

fn parse_dict_key(
    schema: &CftSchema,
    key: &CftValueType,
    text: &str,
) -> Result<LoadedDictKeyDraft, CellValueDiagnostics> {
    let text = text.trim();
    match key {
        CftValueType::String => parse_string(text).map(LoadedDictKeyDraft::String),
        CftValueType::Int => Ok(LoadedDictKeyDraft::Int(i64::from(
            text.parse::<i32>().map_err(|_| type_mismatch("int key"))?,
        ))),
        CftValueType::Long => Ok(LoadedDictKeyDraft::Int(
            text.parse::<i64>().map_err(|_| type_mismatch("int key"))?,
        )),
        CftValueType::Enum(enum_name) => {
            let LoadedValueDraft::EnumVariant { variant, .. } =
                super::parse_enum_variant(schema, enum_name, text)?
            else {
                return Err(type_mismatch("enum key"));
            };
            Ok(LoadedDictKeyDraft::enum_variant(
                enum_name.as_str(),
                variant,
            ))
        }
        other => Err(type_mismatch(&format!(
            "dict key {}",
            other.display_label()
        ))),
    }
}
